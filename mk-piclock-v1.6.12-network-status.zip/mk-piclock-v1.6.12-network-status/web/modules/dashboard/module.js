export async function mount(ctx) {
    const render = status => {
        if (!status) return;
        ctx.setText('#status-time', status.time);
        ctx.setText('#status-date', status.date);
        ctx.setText('#status-name', status.clock_name);
        ctx.setText('#status-version', status.app_version);
        ctx.setText('#status-uptime', ctx.formatUptime(status.uptime_seconds));
        const track = [status.audio_title, status.audio_artist].filter(Boolean).join(' - ') || status.audio_file;
        ctx.setText('#status-audio', status.alarm_active
            ? `Alarm playing at ${status.alarm_volume_percent || 0}%`
            : (status.audio_playing ? `Playing ${track || 'music'}` : 'Audio stopped'));
        ctx.setText('#status-volume', status.alarm_active
            ? `Alarm ${status.alarm_volume_percent || 0}%`
            : `${status.global_volume || 0}%`);
        ctx.setText('#status-display', status.display_mode);
        ctx.setText('#status-touch', status.touch_ok
            ? (status.touch_pressed ? `Pressed on GPIO ${status.touch_gpio}` : `Ready on GPIO ${status.touch_gpio}`)
            : `Unavailable on GPIO ${status.touch_gpio ?? 20}`);
        ctx.setText('#status-font', status.oled_font_name);
        ctx.setText('#status-bedtime', status.bedtime_enabled
            ? `${ctx.timeValue(status.bedtime_start_hour, status.bedtime_start_min)} to ${ctx.timeValue(status.bedtime_end_hour, status.bedtime_end_min)}, ${status.bedtime_dim_percent}%, ${status.clock_24h_mode ? '24-hour' : '12-hour'}`
            : 'Off');
    };

    ctx.status.subscribe(render);
    ctx.on('click', '[data-clock-action]', async (_, button) => {
        try { await ctx.clock(button.dataset.clockAction, {}, button); } catch (_) {}
    });
    ctx.on('click', '#play-first-song', async (_, button) => {
        let music;
        try {
            music = await ctx.json('/api/v1/assets/music');
        } catch (error) {
            ctx.notice(error.message || 'Music library could not be loaded', 'warn', 3000);
            return;
        }

        const track = music.tracks?.[0];
        const file = track?.file || music.files?.[0] || '';
        if (!file) {
            ctx.notice('No music has been uploaded', 'warn', 3000);
            return;
        }

        const label = track?.display || track?.title || file;
        try {
            await ctx.clock('play-music', {file}, button, {
                busyText: `Starting ${label}...`,
                done: `Playing ${label}`,
                errorText: `${label} could not be played`
            });
        } catch (_) {}
    });

    await ctx.status.refresh();

    // Live status is useful on the dashboard only. Editing modules must not
    // be refreshed in the background because that can overwrite form input.
    const statusTimer = window.setInterval(() => {
        ctx.status.refresh().catch(() => {});
    }, 5000);
    ctx.signal.addEventListener('abort', () => window.clearInterval(statusTimer), {once: true});
}
