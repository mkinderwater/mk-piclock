'use strict';

let currentFacePage = 1;
let statusTimer = null;
let lastStatus = null;
let lastMusic = null;
let lastFonts = null;
let messageLimit = null;
let messageFitTimer = null;
let messageFitSeq = 0;
let messageFaces = [];
let lastMessageFit = null;
let activeMessagePreviewFontFile = null;
let activeMessagePreviewFontFamily = '';
let activeMessagePreviewCssPx = null;

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

async function api(path) {
    const res = await fetch(path, { cache: 'no-store' });
    if (!res.ok) throw new Error(path + ' failed');
    return await res.json();
}

function setActionNotice(text, cls, timeoutMs) {
    const el = $('action-notice');
    if (!el) return;
    el.textContent = text || '';
    el.className = 'action-notice ' + (cls || '');
    el.classList.toggle('hidden', !text);
    if (timeoutMs) {
        setTimeout(() => {
            if (el.textContent === text) el.classList.add('hidden');
        }, timeoutMs);
    }
}

function setButtonBusy(button, busy) {
    if (!button) return;
    if (busy) {
        if (!button.dataset.oldText) button.dataset.oldText = button.textContent;
        button.disabled = true;
        button.classList.add('is-busy');
    } else {
        button.disabled = false;
        button.classList.remove('is-busy');
        if (button.dataset.oldText) {
            button.textContent = button.dataset.oldText;
            delete button.dataset.oldText;
        }
    }
}

async function runGuiClockUpdate(opts) {
    const options = opts || {};
    const button = options.button || null;
    const method = options.method || 'GET';
    const body = options.body || null;
    const headers = options.headers || (body instanceof URLSearchParams ? {'Content-Type': 'application/x-www-form-urlencoded'} : undefined);
    const shouldRefreshStatus = options.refreshStatus !== false;

    setButtonBusy(button, true);
    if (button && options.busyText) button.textContent = options.busyText;
    if (options.notice !== false) setActionNotice(options.busyNotice || 'Updating clock...', 'busy');

    let rollback = null;
    try {
        if (typeof options.optimistic === 'function') rollback = options.optimistic() || null;
        const res = await fetch(options.url, { method, body, headers, cache: 'no-store' });
        if (!res.ok) {
            let msg = await res.text();
            try {
                const j = JSON.parse(msg);
                msg = j.error || msg;
            } catch (_) {}
            throw new Error(msg || ('HTTP ' + res.status));
        }
        if (options.notice !== false) setActionNotice(options.doneNotice || 'Done', 'ok', 900);
        if (shouldRefreshStatus) setTimeout(refreshStatus, options.statusDelay || 120);
        if (typeof options.after === 'function') options.after();
        return false;
    } catch (e) {
        if (typeof rollback === 'function') rollback();
        if (typeof options.onError === 'function') options.onError(e);
        setActionNotice(e.message || 'Action failed', 'warn', 3000);
        return false;
    } finally {
        setButtonBusy(button, false);
    }
}

async function sendAction(action, params, button) {
    const qs = new URLSearchParams();
    qs.set('do', action);
    qs.set('format', 'json');
    if (params) Object.keys(params).forEach(k => qs.set(k, params[k]));
    return runGuiClockUpdate({
        url: '/action?' + qs.toString(),
        button,
        busyText: 'Working...',
        busyNotice: 'Updating clock...',
        doneNotice: 'Clock updated'
    });
}

async function showFaceFromButton(button) {
    const file = button ? button.dataset.file : '';
    if (!file) return false;
    const qs = new URLSearchParams({file, format: 'json'});
    return runGuiClockUpdate({
        url: '/face?' + qs.toString(),
        button,
        busyText: 'Showing...',
        busyNotice: 'Sending face to OLED...',
        doneNotice: 'Face sent to OLED'
    });
}

function decrementFaceCountText(id) {
    const el = $(id);
    if (!el) return;
    const textNow = String(el.value != null ? el.value : el.textContent);
    const m = textNow.match(/(\d+)/);
    if (!m) return;
    const next = Math.max(0, parseInt(m[1], 10) - 1);
    const text = next ? (next + ' uploaded') : (id === 'face-count' ? 'No faces uploaded' : 'No bedtime faces uploaded');
    if (el.value != null) el.value = text;
    else el.textContent = text;
}

async function deleteFaceFromButton(button) {
    const file = button ? button.dataset.file : '';
    const kind = button ? (button.dataset.kind || 'normal') : 'normal';
    if (!file) return false;
    if (!confirm('Delete ' + file + '?')) return false;

    const card = button.closest('.face-card');
    const parent = card ? card.parentElement : null;
    const nextSibling = card ? card.nextSibling : null;
    const body = new URLSearchParams({file, kind, format: 'json'});

    return runGuiClockUpdate({
        url: '/delete-face',
        method: 'POST',
        body,
        button,
        busyText: 'Deleting...',
        busyNotice: 'Deleting face...',
        doneNotice: 'Face deleted',
        optimistic: () => {
            if (card) {
                card.classList.add('removing');
                setTimeout(() => { if (card.parentElement) card.remove(); }, 80);
            }
            decrementFaceCountText(kind === 'bedtime' ? 'bedtime-face-count' : 'face-count');
            return () => {
                if (card && parent && !card.parentElement) parent.insertBefore(card, nextSibling);
                if (card) card.classList.remove('removing');
                loadFaces();
            };
        },
        after: () => {
            messageFaces = messageFaces.filter(f => f.file !== file);
            const sel = $('message_face_file');
            if (sel) {
                Array.from(sel.options).forEach(opt => { if (opt.value === file) opt.remove(); });
                updateMessageFacePreview();
            }
        },
        onError: () => loadFaces()
    });
}


async function deleteAllFaces(button) {
    if (!confirm('Delete ALL normal and bedtime faces, including saved source PNGs?')) return false;
    const body = new URLSearchParams({format: 'json'});
    return runGuiClockUpdate({
        url: '/delete-all-faces',
        method: 'POST',
        body,
        button,
        busyText: 'Deleting...',
        busyNotice: 'Deleting all faces...',
        doneNotice: 'All faces deleted',
        optimistic: () => {
            const normalList = $('face-list');
            const bedtimeList = $('bedtime-face-list');
            const faceCount = $('face-count');
            const bedtimeCount = $('bedtime-face-count');
            const oldNormal = normalList ? normalList.innerHTML : '';
            const oldBedtime = bedtimeList ? bedtimeList.innerHTML : '';
            const oldFaceCount = faceCount ? faceCount.value : '';
            const oldBedtimeCount = bedtimeCount ? bedtimeCount.textContent : '';
            if (normalList) normalList.innerHTML = '<div class="card"><p>No normal faces yet. Upload one or more PNG files above.</p></div>';
            if (bedtimeList) bedtimeList.innerHTML = '<div class="card"><p>No bedtime faces yet. Upload calm bedtime-only PNG files above.</p></div>';
            if (faceCount) faceCount.value = 'No faces uploaded';
            if (bedtimeCount) bedtimeCount.textContent = 'No bedtime faces uploaded';
            messageFaces = [];
            updateMessageFacePreview();
            return () => {
                if (normalList) normalList.innerHTML = oldNormal;
                if (bedtimeList) bedtimeList.innerHTML = oldBedtime;
                if (faceCount) faceCount.value = oldFaceCount;
                if (bedtimeCount) bedtimeCount.textContent = oldBedtimeCount;
                loadFaces();
            };
        },
        after: () => {
            messageFaces = [];
            const sel = $('message_face_file');
            if (sel) sel.innerHTML = '<option value="">No uploaded faces</option>';
            updateMessageFacePreview();
            loadFaces();
        },
        onError: () => loadFaces()
    });
}

async function deleteAllMusic(button) {
    if (!confirm('Delete ALL uploaded MP3 files and reset alarm music choices to Random?')) return false;
    const body = new URLSearchParams({format: 'json'});
    return runGuiClockUpdate({
        url: '/delete-all-music',
        method: 'POST',
        body,
        button,
        busyText: 'Deleting...',
        busyNotice: 'Deleting all music...',
        doneNotice: 'All music deleted',
        optimistic: () => {
            const list = $('music-list');
            const count = $('music-count');
            const current = $('music-current');
            const oldList = list ? list.innerHTML : '';
            const oldCount = count ? count.textContent : '';
            const oldCurrent = current ? current.textContent : '';
            if (list) list.innerHTML = '<p class="small">No uploaded MP3 files yet.</p>';
            if (count) count.textContent = '0';
            if (current) current.textContent = 'None';
            if (lastMusic) lastMusic.files = [];
            return () => {
                if (list) list.innerHTML = oldList;
                if (count) count.textContent = oldCount;
                if (current) current.textContent = oldCurrent;
                loadMusic();
            };
        },
        after: () => {
            loadMusic();
            refreshStatus();
        },
        onError: () => loadMusic()
    });
}

function setMessageSendStatus(text, cls) {
    const el = $('message_send_status');
    if (!el) return;
    el.textContent = text || '';
    el.className = 'message-send-status ' + (cls || '');
    el.classList.toggle('hidden', !text);
}

function clearMessageText(focusBox) {
    const box = $('message_text');
    if (!box) return false;
    box.value = '';
    lastMessageFit = null;
    updateMessageCounter();
    updateMessageOledPreview([]);
    scheduleMessageFitCheck();
    setMessageSendStatus('', '');
    if (focusBox) box.focus();
    return false;
}

async function submitMessage(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const button = $('message_submit');
    const box = $('message_text');
    const body = new URLSearchParams(new FormData(form));
    body.set('format', 'json');
    setMessageSendStatus('', '');
    return runGuiClockUpdate({
        url: '/show-message',
        method: 'POST',
        body,
        button,
        busyText: 'Sending...',
        busyNotice: 'Sending message to screen...',
        doneNotice: 'Message sent to screen',
        after: () => {
            setMessageSendStatus('Sent to the clock. Ready for the next message.', 'ok');
            clearMessageText(false);
            setMessageSendStatus('Sent to the clock. Ready for the next message.', 'ok');
            if (box) box.focus();
            loadLog();
        },
        onError: (e) => {
            setMessageSendStatus(e.message || 'Message was not sent.', 'warn');
        }
    });
}

function $(id) { return document.getElementById(id); }
function pad2(n) { return String(n).padStart(2, '0'); }
function timeVal(h, m) { return pad2(h) + ':' + pad2(m); }

function formatUptime(seconds) {
    let s = Math.max(0, parseInt(seconds || 0, 10));
    const days = Math.floor(s / 86400);
    s %= 86400;
    const hours = Math.floor(s / 3600);
    s %= 3600;
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    if (days > 0) return days + 'd ' + hours + 'h ' + mins + 'm';
    if (hours > 0) return hours + 'h ' + mins + 'm ' + secs + 's';
    if (mins > 0) return mins + 'm ' + secs + 's';
    return secs + 's';
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}


function fontPreviewId(name) {
    const text = String(name || 'font');
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) {
        h ^= text.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return 'fp_' + (h >>> 0).toString(36);
}

function registerUploadedFontPreviews(fonts) {
    let style = document.getElementById('uploaded-font-preview-styles');
    if (!style) {
        style = document.createElement('style');
        style.id = 'uploaded-font-preview-styles';
        document.head.appendChild(style);
    }

    const rules = (fonts || []).map(name => {
        const id = fontPreviewId(name);
        return '@font-face { font-family: "' + id + '"; src: url("/font-file?file=' + encodeURIComponent(name) + '"); font-display: swap; } .font-sample-' + id + ' { font-family: "' + id + '", ui-sans-serif, system-ui, sans-serif; }';
    });
    style.textContent = rules.join('\n');
}



function activeMessageFontFamilyName(fontName) {
    return 'active_msg_' + fontPreviewId(fontName);
}

function registerActiveMessageFont(fontName) {
    let style = document.getElementById('active-message-font-style');
    if (!style) {
        style = document.createElement('style');
        style.id = 'active-message-font-style';
        document.head.appendChild(style);
    }

    const stableName = fontName || '';
    if (activeMessagePreviewFontFile === stableName) {
        return activeMessagePreviewFontFamily;
    }

    activeMessagePreviewFontFile = stableName;
    if (!stableName) {
        activeMessagePreviewFontFamily = '';
        if (style.textContent) style.textContent = '';
        return '';
    }

    activeMessagePreviewFontFamily = activeMessageFontFamilyName(stableName);
    style.textContent = '@font-face { font-family: "' + activeMessagePreviewFontFamily + '"; src: url("/font-file?file=' + encodeURIComponent(stableName) + '"); font-display: block; }';
    return activeMessagePreviewFontFamily;
}

function setPreviewStyleValue(el, key, value) {
    if (el.style[key] !== value) el.style[key] = value;
}

function applyActiveMessagePreviewFont() {
    const box = $('message_text');
    const hint = $('message_oled_font_hint');
    if (!box) return;

    const statusFontFile = lastStatus && lastStatus.oled_font_file ? lastStatus.oled_font_file : '';
    const statusFontName = lastStatus && lastStatus.oled_font_name ? lastStatus.oled_font_name : (statusFontFile || 'Built-in clock font');
    const statusFontSize = lastStatus && lastStatus.oled_font_size ? Number(lastStatus.oled_font_size) : 18;
    const msgPx = Math.max(12, Math.min(18, statusFontSize || 18));

    /* Browser preview is scaled from the 256x64 OLED. 18 OLED pixels looks about right at this panel size. */
    const cssPx = Math.max(13, Math.min(23, Math.round(msgPx * 1.18)));
    if (activeMessagePreviewCssPx !== cssPx) {
        activeMessagePreviewCssPx = cssPx;
        setPreviewStyleValue(box, 'fontSize', cssPx + 'px');
        setTimeout(() => centerMessageInputLikeScreen(), 0);
    }

    if (statusFontFile) {
        const family = registerActiveMessageFont(statusFontFile);
        const fontStack = '"' + family + '", ui-sans-serif, system-ui, sans-serif';
        if (box.dataset.previewFontStack !== fontStack) {
            box.dataset.previewFontStack = fontStack;
            setPreviewStyleValue(box, 'fontFamily', fontStack);
        }
        box.classList.remove('builtin-preview-font');
        if (hint && hint.dataset.previewHint !== statusFontFile + ':' + msgPx) {
            hint.dataset.previewHint = statusFontFile + ':' + msgPx;
            hint.textContent = 'Input font: ' + statusFontFile + ' at screen message size ' + msgPx + 'px';
        }
    } else {
        registerActiveMessageFont('');
        const fontStack = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
        if (box.dataset.previewFontStack !== fontStack) {
            box.dataset.previewFontStack = fontStack;
            setPreviewStyleValue(box, 'fontFamily', fontStack);
        }
        box.classList.add('builtin-preview-font');
        if (hint && hint.dataset.previewHint !== 'builtin:' + statusFontName) {
            hint.dataset.previewHint = 'builtin:' + statusFontName;
            hint.textContent = 'Input font: ' + statusFontName + ' (browser approximation of built-in screen font)';
        }
    }
}

function fontSampleHtml(name) {
    const id = fontPreviewId(name);
    return '<div class="font-sample-box font-sample-' + id + '">' +
        '<div>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div>' +
        '<div>1234567890</div>' +
    '</div>';
}

function updateSelectedFontPreview() {
    const holder = $('selected-font-preview');
    if (!holder || !lastFonts) return;
    const selected = $('oled_font_file') ? $('oled_font_file').value : '';
    if (selected) {
        holder.innerHTML = '<div class="font-preview-card"><div class="font-name">' + esc(selected) + '</div>' + fontSampleHtml(selected) + '</div>';
        return;
    }
    const builtinSelect = $('oled_font');
    const builtinId = builtinSelect ? parseInt(builtinSelect.value || lastFonts.builtin || 0, 10) : (lastFonts.builtin || 0);
    const fallback = (lastFonts.builtin_fonts || []).find(f => f.id === builtinId);
    holder.innerHTML = '<div class="font-preview-card builtin-font-preview"><div class="font-name">' + esc(fallback ? fallback.name : 'Built-in') + '</div><div class="font-sample-box builtin-sample"><div>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div><div>1234567890</div></div><div class="small muted">Built-in OLED font preview is approximated in the browser.</div></div>';
}

function pathSection() {
    if (location.pathname === '/faces') return 'faces';
    if (location.pathname === '/music') return 'music';
    if (location.pathname === '/message') return 'message';
    if (location.pathname === '/alarm') return 'alarm';
    if (location.pathname === '/display') return 'display';
    if (location.pathname === '/log') return 'log';
    return 'home';
}

function sectionPath(section) {
    if (section === 'faces') return '/faces';
    if (section === 'music') return '/music';
    if (section === 'message') return '/message';
    if (section === 'alarm') return '/alarm';
    if (section === 'display') return '/display';
    if (section === 'log') return '/log';
    return '/';
}

function facePage() {
    const params = new URLSearchParams(location.search);
    let page = parseInt(params.get('page') || String(currentFacePage), 10);
    if (!Number.isFinite(page) || page < 1) page = 1;
    return page;
}

function showSection(section, push) {
    const valid = ['home', 'faces', 'music', 'message', 'alarm', 'display', 'log'];
    if (!valid.includes(section)) section = 'home';

    document.querySelectorAll('.panel').forEach(panel => panel.classList.add('hidden'));
    const active = $('section-' + section);
    if (active) active.classList.remove('hidden');

    if ($('section-select')) $('section-select').value = section;

    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.section === section);
    });

    if (push) {
        history.pushState({}, '', sectionPath(section) + (section === 'faces' ? '?page=' + currentFacePage : ''));
    }

    if (section === 'faces') loadFaces();
    if (section === 'music') loadMusic();
    if (section === 'message') loadMessage();
    if (section === 'alarm') loadAlarms();
    if (section === 'display') loadDisplay();
    if (section === 'log') loadLog();
}

window.onpopstate = function () { showSection(pathSection(), false); };

async function refreshStatus() {
    try {
        const s = await api('/api/status');
        lastStatus = s;
        $('status-time').textContent = s.time;
        $('status-date').textContent = s.date;
        $('status-name').textContent = s.clock_name || '';
        $('status-version').textContent = s.app_version || '';
        $('status-uptime').textContent = formatUptime(s.uptime_seconds || 0);
        $('status-audio').textContent = s.alarm_active ? ('Alarm playing at ' + String(s.alarm_volume_percent ?? 0) + '%') : (s.audio_playing ? 'Playing' : 'Stopped');
        $('status-volume').textContent = s.alarm_active ? ('Alarm ' + String(s.alarm_volume_percent ?? 0) + '%') : (String(s.global_volume ?? 0) + '%');
        $('status-display').textContent = s.display_mode;
        $('status-font').textContent = s.oled_font_name || '';
        applyActiveMessagePreviewFont();
        $('status-bedtime').textContent = s.bedtime_enabled ? (timeVal(s.bedtime_start_hour, s.bedtime_start_min) + ' to ' + timeVal(s.bedtime_end_hour, s.bedtime_end_min) + ', ' + s.bedtime_dim_percent + '%, ' + (s.clock_24h_mode ? '24-hour' : '12-hour')) : 'Off';
        $('oled-pill').textContent = s.oled_ok ? 'OLED OK' : 'OLED OFF';
        $('oled-pill').className = s.oled_ok ? 'pill ok' : 'pill warn';
        $('music-status').textContent = s.audio_playing ? 'Playing' : 'Stopped';
        $('music-current').textContent = s.audio_file || '-';
        $('global_volume').value = s.global_volume ?? 80;
        $('clock_name').value = s.clock_name || '';
        $('startup-name-preview').textContent = s.clock_name || '';
        $('startup-version-preview').textContent = s.app_version || '';
        setDisplayInputs(s);
    } catch (e) {
        $('oled-pill').textContent = 'Offline';
        $('oled-pill').className = 'pill warn';
    }
}

function setDisplayInputs(s) {
    if (!$('bedtime_enabled')) return;
    $('bedtime_enabled').value = String(s.bedtime_enabled ? 1 : 0);
    $('bedtime_dim_percent').value = s.bedtime_dim_percent ?? 35;
    if ($('clock_24h_mode')) $('clock_24h_mode').value = s.clock_24h_mode ? '1' : '0';
    if ($('bed_clock_24h_mode')) $('bed_clock_24h_mode').value = s.clock_24h_mode ? '1' : '0';
    $('bedtime_start').value = timeVal(s.bedtime_start_hour ?? 21, s.bedtime_start_min ?? 0);
    $('bedtime_end').value = timeVal(s.bedtime_end_hour ?? 7, s.bedtime_end_min ?? 0);

    $('bed_oled_font_file').value = s.oled_font_file || '';
    $('bed_oled_font').value = s.oled_font ?? 0;
    $('bed_oled_font_size').value = s.oled_font_size ?? 42;

    $('font_bedtime_enabled').value = String(s.bedtime_enabled ? 1 : 0);
    $('font_bedtime_start').value = $('bedtime_start').value;
    $('font_bedtime_end').value = $('bedtime_end').value;
    $('font_bedtime_dim_percent').value = s.bedtime_dim_percent ?? 35;
}

function renderFaceCards(list, faces, emptyText, showButton, kind) {
    list.innerHTML = '';
    if (!faces.length) {
        list.innerHTML = '<div class="card"><p>' + esc(emptyText) + '</p></div>';
        return;
    }

    faces.forEach(face => {
        const card = document.createElement('div');
        card.className = 'card face-card';
        const img = face.preview_url
            ? '<img class="face-preview-img" src="' + esc(face.preview_url) + '" alt="' + esc(face.title || face.file) + '">'
            : '<div class="face-preview-missing">RAW</div>';
        const source = face.source_png
            ? '<p class="small mono">Source PNG: ' + esc(face.source_png) + '</p>'
            : '<p class="small mono muted">Source PNG: not available for this older RAW-only face</p>';
        card.innerHTML =
            '<div class="card-title-row"><h2>' + esc(face.title || face.file) + '</h2><span class="badge ok">Uploaded</span></div>' +
            '<div class="face-card-layout">' + img + '<div>' +
                source +
                '<p class="small mono">OLED RAW: ' + esc(face.file) + '</p>' +
                '<div class="face-actions">' +
                    (showButton ? '<button class="btn alt" type="button" onclick="showFaceFromButton(this)" data-file="' + esc(face.file) + '">Show Face</button>' : '') +
                    '<button class="btn danger" type="button" onclick="deleteFaceFromButton(this)" data-kind="' + esc(kind || 'normal') + '" data-file="' + esc(face.file) + '">Delete</button>' +
                '</div>' +
            '</div></div>';
        list.appendChild(card);
    });
}

async function loadFaces() {
    try {
        const data = await api('/api/faces?page=' + facePage());
        currentFacePage = data.page;

        const sel = $('face-page-select');
        sel.innerHTML = '';
        for (let p = 1; p <= data.max_page; p++) {
            const opt = document.createElement('option');
            opt.value = p;
            opt.textContent = 'Page ' + p;
            if (p === data.page) opt.selected = true;
            sel.appendChild(opt);
        }

        $('face-count').value = data.count ? (String(data.count) + ' uploaded') : 'No faces uploaded';
        renderFaceCards($('face-list'), data.faces, 'No normal faces yet. Upload one or more PNG files above.', true, 'normal');
    } catch (e) {
        $('face-list').innerHTML = '<div class="card"><p>Could not load normal faces.</p></div>';
    }

    try {
        const bedtime = await api('/api/faces?kind=bedtime&all=1');
        $('bedtime-face-count').textContent = bedtime.count ? (String(bedtime.count) + ' uploaded') : 'No bedtime faces uploaded';
        renderFaceCards($('bedtime-face-list'), bedtime.faces, 'No bedtime faces yet. Upload calm bedtime-only PNG files above.', false, 'bedtime');
    } catch (e) {
        $('bedtime-face-count').textContent = 'Could not load';
        $('bedtime-face-list').innerHTML = '<div class="card"><p>Could not load bedtime faces.</p></div>';
    }
}

function setFacePage(page) {
    currentFacePage = parseInt(page, 10) || 1;
    history.replaceState({}, '', '/faces?page=' + currentFacePage);
    loadFaces();
}

async function loadMusic() {
    try {
        const data = await api('/api/music');
        lastMusic = data;
        $('music-count').textContent = String(data.files.length);
        $('global_volume').value = data.global_volume ?? 80;
        const list = $('music-list');
        list.innerHTML = '';
        if (!data.files.length) {
            list.innerHTML = '<p class="small">No uploaded MP3 files yet.</p>';
            return;
        }
        data.files.forEach(name => {
            const card = document.createElement('div');
            card.className = 'mini-card song-card';
            card.innerHTML =
                '<div class="font-name">' + esc(name) + '</div>' +
                '<div class="mini-actions">' +
                    '<button class="btn ok small-btn" type="button" onclick="sendAction(\'play-music\',{file:this.dataset.file})" data-file="' + esc(name) + '">Play</button>' +
                    '<button class="btn danger small-btn" type="button" onclick="sendAction(\'stop\')">Stop</button>' +
                '</div>';
            list.appendChild(card);
        });
    } catch (e) {
        $('music-list').innerHTML = '<p class="small">Could not load music.</p>';
    }
}

function musicOptions(selected) {
    const files = lastMusic ? lastMusic.files : [];
    let html = '<option value="">Random uploaded MP3</option>';
    files.forEach(name => {
        html += '<option value="' + esc(name) + '"' + (name === selected ? ' selected' : '') + '>' + esc(name) + '</option>';
    });
    return html;
}

function dayCheckboxes(mask) {
    let html = '<div class="day-grid">';
    for (let d = 0; d < 7; d++) {
        const checked = (mask & (1 << d)) ? ' checked' : '';
        html += '<label class="day-pill"><input type="checkbox" name="day' + d + '" value="1"' + checked + '> ' + dayNames[d] + '</label>';
    }
    html += '</div>';
    return html;
}


async function loadMessageLimit() {
    try {
        messageLimit = await api('/api/message-limit');
    } catch (e) {
        messageLimit = { max_chars: 180, max_lines: 3, wrap_check: 1 };
    }

    const box = $('message_text');
    if (box) {
        box.maxLength = messageLimit.max_chars || 180;
    }
    updateMessageCounter();
}

async function checkMessageFitNow() {
    const box = $('message_text');
    const status = $('message_fit_status');
    const submit = $('message_submit');
    if (!box || !status || !submit) return;

    const text = box.value || '';
    const requestSeq = ++messageFitSeq;
    const max = messageLimit && messageLimit.max_chars ? messageLimit.max_chars : 180;
    if (text.length > max) {
        status.textContent = 'Too long for screen';
        status.className = 'warn-text';
        submit.disabled = true;
        return;
    }
    if (!text.trim()) {
        status.textContent = 'Enter a message. Fit is checked against the screen layout.';
        status.className = 'muted';
        submit.disabled = false;
        return;
    }

    try {
        const fit = await api('/api/message-fit?text=' + encodeURIComponent(text));
        if (requestSeq !== messageFitSeq || box.value !== text) return;
        fit.text = text;
        lastMessageFit = fit;
        updateMessageOledPreview(fit.lines);
        if (fit.ok) {
            status.textContent = 'Fits screen with wrap';
            status.className = 'ok-text';
            submit.disabled = false;
        } else {
            status.textContent = fit.reason || 'Too long for screen';
            status.className = 'warn-text';
            submit.disabled = true;
        }
    } catch (e) {
        status.textContent = 'Limit check unavailable';
        status.className = 'muted';
        submit.disabled = text.length > max;
    }
}

function updateMessageCounter() {
    const box = $('message_text');
    const counter = $('message_counter');
    const status = $('message_fit_status');
    const submit = $('message_submit');
    if (!box || !counter) return;

    const max = messageLimit && messageLimit.max_chars ? messageLimit.max_chars : (box.maxLength > 0 ? box.maxLength : 180);
    counter.textContent = String(box.value.length) + ' / ' + String(max) + ' chars, wrap-checked';

    if (box.value.length > max) {
        if (status) {
            status.textContent = 'Too long for screen';
            status.className = 'warn-text';
        }
        if (submit) submit.disabled = true;
    }
}

function approximateMessagePreviewLines(text) {
    const clean = String(text || '').replace(/\s+/g, ' ').trim();
    if (!clean) return [];

    const maxChars = 20;
    const out = [];
    let line = '';
    clean.split(' ').forEach(word => {
        const test = line ? (line + ' ' + word) : word;
        if (test.length <= maxChars || !line) {
            line = test;
        } else {
            out.push(line);
            line = word;
        }
    });
    if (line) out.push(line);
    return out.slice(0, 3);
}

function setOledPreviewFace(face) {
    const img = $('message_oled_face_img');
    const missing = $('message_oled_face_missing');
    if (!img || !missing) return;

    if (face && face.preview_url) {
        img.src = face.preview_url;
        img.classList.remove('hidden');
        missing.classList.add('hidden');
    } else {
        img.removeAttribute('src');
        img.classList.add('hidden');
        missing.classList.remove('hidden');
    }
}

function getMessagePreviewLines(linesFromServer) {
    const box = $('message_text');
    const text = box ? (box.value || '') : '';
    if (Array.isArray(linesFromServer) && linesFromServer.length) return linesFromServer;
    if (lastMessageFit && lastMessageFit.text === text && Array.isArray(lastMessageFit.lines) && lastMessageFit.lines.length) {
        return lastMessageFit.lines;
    }
    return approximateMessagePreviewLines(text);
}

function centerMessageInputLikeScreen(linesFromServer) {
    const box = $('message_text');
    if (!box) return;

    const lines = getMessagePreviewLines(linesFromServer);
    const visibleLines = Math.max(1, Math.min(3, lines.length || 1));
    const style = window.getComputedStyle(box);
    const lineHeight = parseFloat(style.lineHeight) || ((parseFloat(style.fontSize) || 18) * 1.1);
    const available = box.clientHeight || 64;
    const textHeight = visibleLines * lineHeight;
    const pad = Math.max(4, Math.round((available - textHeight) / 2));

    const next = pad + 'px';
    if (box.style.paddingTop !== next) box.style.paddingTop = next;
    if (box.style.paddingBottom !== next) box.style.paddingBottom = next;
    box.style.setProperty('--screen-preview-lines', String(visibleLines));
}

function updateMessageOledPreview(linesFromServer) {
    const sel = $('message_face_file');
    const box = $('message_text');
    if (!box) return;
    applyActiveMessagePreviewFont();
    centerMessageInputLikeScreen(linesFromServer);

    const face = sel ? messageFaces.find(f => f.file === sel.value) : null;
    setOledPreviewFace(face);
}

function scheduleMessageFitCheck() {
    updateMessageCounter();
    updateMessageOledPreview();
    if (messageFitTimer) clearTimeout(messageFitTimer);
    messageFitTimer = setTimeout(checkMessageFitNow, 220);
}

function bindMessageLimitEvents() {
    const box = $('message_text');
    if (!box || box.dataset.boundLimit === '1') return;
    box.dataset.boundLimit = '1';
    box.addEventListener('input', scheduleMessageFitCheck);
}

function updateMessageFacePreview() {
    const sel = $('message_face_file');
    if (!sel) return;

    const face = messageFaces.find(f => f.file === sel.value);
    sel.title = face ? ((face.title || face.file) + (face.source_png ? (' / ' + face.source_png) : '')) : 'No face selected';
    updateMessageOledPreview();
}

async function loadMessage() {
    bindMessageLimitEvents();
    if (!lastStatus) await refreshStatus();
    applyActiveMessagePreviewFont();
    await loadMessageLimit();
    try {
        const data = await api('/api/faces?all=1');
        const sel = $('message_face_file');
        if (!sel) return;
        sel.innerHTML = '';

        messageFaces = data.faces || [];

        if (!messageFaces.length) {
            sel.innerHTML = '<option value="">No uploaded faces</option>';
            updateMessageFacePreview();
            updateMessageOledPreview();
            return;
        }

        messageFaces.forEach(face => {
            const opt = document.createElement('option');
            opt.value = face.file;
            opt.textContent = (face.title || face.file) + (face.source_png ? ('  (' + face.source_png + ')') : '');
            sel.appendChild(opt);
        });
        if (sel.dataset.boundPreview !== '1') {
            sel.dataset.boundPreview = '1';
            sel.addEventListener('change', updateMessageFacePreview);
        }
        updateMessageFacePreview();
    } catch (e) {
        messageFaces = [];
        const sel = $('message_face_file');
        if (sel) sel.innerHTML = '<option value="">No uploaded faces</option>';
        updateMessageFacePreview();
    }
    updateMessageCounter();
    scheduleMessageFitCheck();
}


function renderLogEntries(entries) {
    const list = $('log-list');
    if (!list) return;
    list.innerHTML = '';
    if (!entries || !entries.length) {
        list.innerHTML = '<div class="log-empty">No log entries yet.</div>';
        return;
    }
    entries.forEach(line => {
        const div = document.createElement('div');
        div.className = 'log-line mono';
        div.textContent = line;
        list.appendChild(div);
    });
    list.scrollTop = list.scrollHeight;
}

async function loadLog(button) {
    setButtonBusy(button, true);
    if (button) button.textContent = 'Refreshing...';
    try {
        const data = await api('/api/log');
        renderLogEntries(data.entries || []);
        const meta = $('log-meta');
        if (meta) meta.textContent = (data.entries || []).length + ' recent entries from ' + (data.log_file || 'event log');
    } catch (e) {
        const meta = $('log-meta');
        if (meta) meta.textContent = 'Could not load log.';
        renderLogEntries([]);
    } finally {
        setButtonBusy(button, false);
    }
}

async function clearLog(button) {
    if (!confirm('Clear the event log?')) return false;
    const body = new URLSearchParams({format: 'json'});
    return runGuiClockUpdate({
        url: '/clear-log',
        method: 'POST',
        body,
        button,
        busyText: 'Clearing...',
        busyNotice: 'Clearing log...',
        doneNotice: 'Log cleared',
        refreshStatus: false,
        after: () => loadLog()
    });
}

async function loadAlarms() {
    await loadMusic();
    await refreshStatus();
    const list = $('alarm-list');
    list.innerHTML = '';
    const alarms = (lastStatus && lastStatus.alarms) ? lastStatus.alarms : [];
    if (!alarms.length) {
        list.innerHTML = '<div class="card"><p>Could not load alarms.</p></div>';
        return;
    }
    alarms.forEach(alarm => {
        const card = document.createElement('div');
        card.className = 'card alarm-card';
        card.innerHTML =
            '<div class="card-title-row"><h2>Alarm ' + alarm.id + '</h2><span class="badge ' + (alarm.enabled ? 'ok' : '') + '">' + (alarm.enabled ? 'On' : 'Off') + '</span></div>' +
            '<form method="POST" action="/save-alarm">' +
                '<input type="hidden" name="id" value="' + alarm.id + '">' +
                '<div class="field-row">' +
                    '<div><label>Enabled</label><select name="enabled"><option value="1"' + (alarm.enabled ? ' selected' : '') + '>On</option><option value="0"' + (!alarm.enabled ? ' selected' : '') + '>Off</option></select></div>' +
                    '<div><label>Time</label><input type="time" name="time" value="' + timeVal(alarm.hour, alarm.min) + '"></div>' +
                '</div>' +
                '<label>Weekdays</label>' + dayCheckboxes(alarm.weekdays) +
                '<label>Music</label><select name="music_file">' + musicOptions(alarm.music_file) + '</select>' +
                '<div class="field-row">' +
                    '<div><label>Start volume %</label><input type="number" name="start_volume" min="0" max="100" value="' + alarm.start_volume + '"></div>' +
                    '<div><label>End volume %</label><input type="number" name="end_volume" min="0" max="100" value="' + alarm.end_volume + '"></div>' +
                '</div>' +
                '<button class="btn" type="submit">Save Alarm ' + alarm.id + '</button>' +
            '</form>';
        list.appendChild(card);
    });
}

async function loadDisplay() {
    await Promise.all([refreshStatus(), loadFonts()]);
}

async function loadFonts() {
    try {
        const data = await api('/api/fonts');
        lastFonts = data;
        registerUploadedFontPreviews(data.uploaded_fonts || []);
        $('oled_font_size').value = data.font_size;

        const uploaded = $('oled_font_file');
        uploaded.innerHTML = '';
        const none = document.createElement('option');
        none.value = '';
        none.textContent = 'Use built-in font';
        if (!data.selected) none.selected = true;
        uploaded.appendChild(none);

        data.uploaded_fonts.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            if (name === data.selected) opt.selected = true;
            uploaded.appendChild(opt);
        });

        const builtin = $('oled_font');
        builtin.innerHTML = '';
        data.builtin_fonts.forEach(font => {
            const opt = document.createElement('option');
            opt.value = font.id;
            opt.textContent = font.name;
            if (font.id === data.builtin) opt.selected = true;
            builtin.appendChild(opt);
        });

        const fallback = data.builtin_fonts.find(f => f.id === data.builtin);
        $('selected-font').textContent = data.selected || (fallback ? fallback.name : 'Built-in');
        updateSelectedFontPreview();
        if (uploaded) uploaded.onchange = updateSelectedFontPreview;
        if (builtin) builtin.onchange = updateSelectedFontPreview;

        const del = $('delete-fonts');
        del.innerHTML = '';
        if (!data.uploaded_fonts.length) {
            del.innerHTML = '<p class="small">No uploaded fonts yet.</p>';
            return;
        }

        data.uploaded_fonts.forEach(name => {
            const card = document.createElement('div');
            card.className = 'mini-card';
            card.innerHTML =
                '<div class="font-name">' + esc(name) + '</div>' +
                fontSampleHtml(name) +
                '<form method="POST" action="/delete-font">' +
                    '<input type="hidden" name="font" value="' + esc(name) + '">' +
                    '<button class="btn danger small-btn" type="submit">Delete</button>' +
                '</form>';
            del.appendChild(card);
        });
    } catch (e) {
        $('selected-font').textContent = 'Could not load fonts';
    }
}

function playFirstMusic() {
    if (lastMusic && lastMusic.files && lastMusic.files.length) {
        sendAction('play-music', { file: lastMusic.files[0] });
    } else {
        sendAction('play-music');
    }
}

function initApp() {
    currentFacePage = facePage();
    showSection(pathSection(), false);
    refreshStatus();
    loadMusic();
    statusTimer = setInterval(refreshStatus, 5000);
}
