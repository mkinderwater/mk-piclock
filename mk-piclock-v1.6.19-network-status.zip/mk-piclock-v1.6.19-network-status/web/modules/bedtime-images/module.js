import {mountImageLibrary} from '/assets/js/image-library.js?v=175';

export function mount(ctx) {
    return mountImageLibrary(ctx, {
        heading: 'Bedtime Images',
        labelSingular: 'Bedtime Image',
        labelPlural: 'Bedtime Images',
        description: 'Upload calm bedtime-only PNG files. These are used only during bedtime hours and rotate every five minutes.',
        emptyText: 'No bedtime images yet. Upload PNG files above.',
        listUrl: '/api/v1/assets/bedtime-images',
        uploadUrl: '/api/v1/assets/bedtime-images/upload',
        deleteUrl: '/api/v1/assets/bedtime-images/delete',
        deleteAllUrl: '/api/v1/assets/bedtime-images/delete-all',
        allowShow: false,
        bedtime: true
    });
}
