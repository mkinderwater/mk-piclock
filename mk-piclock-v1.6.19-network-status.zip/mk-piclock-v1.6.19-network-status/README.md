# mk-piclock v1.6.19

mk-piclock is a native C alarm clock for Raspberry Pi with a 256x64 SSD1322 OLED, MAX98357A audio, touch input, uploaded images, bedtime images, music, alarms, messages, and a modular web GUI.

## Architecture

Two restricted processes are installed:

- `mk-piclock-core`: owns OLED, GPIO, audio, alarms, rendering, and persistent settings.
- `mk-piclock-api`: serves the GUI and HTTP API, validates uploads, and manages assets.

They communicate through `/run/mk-piclock/core.sock` using private binary IPC version 6. The API does not run as root.

## GUI modules

- Dashboard
- Images
- Bedtime Images
- Music
- Message
- Alarms
- Display
- Log

Images and bedtime images have separate menus, storage directories, upload controls, paging, and delete-all actions.

## Storage

```text
/opt/mk-piclock/assets/images
/opt/mk-piclock/assets/bedtime-images
/opt/mk-piclock/assets/music
/opt/mk-piclock/assets/fonts
/opt/mk-piclock/config/clock.conf
/opt/mk-piclock/config/event.log
```

Normal and bedtime images are stored by filename. Numeric image IDs and old `faces` directories are not used.

## Display behaviour

- Dashboard mirrors the exact 256x64 framebuffer sent to the OLED.
- The GUI can identify the physical panel as Yellow, Green, or White so browser previews resemble the installed OLED.
- Panel colour is hardware-defined. The setting changes GUI previews only.
- Bedtime brightness is a live 0 to 100 slider.
- Song metadata stays centred when it fits the footer.
- Long `Title - Artist` metadata scrolls continuously from right to left.
- Common accented Latin metadata is rendered without byte-by-byte `?` substitution.

## Image requirements

Upload PNG files through Images or Bedtime Images. The API stores:

- the source PNG for GUI previews
- a converted 64x64 four-bit raw image for the OLED

Use high-contrast artwork designed for a black background and the OLED's limited grayscale range.

## API

The built-in GUI uses API version 1.1 under `/api/v1`.

```text
GET http://<clock-ip>:8080/api/v1
GET http://<clock-ip>:8080/api/v1/status
GET http://<clock-ip>:8080/api/v1/openapi.json
```

The API has no authentication and is intended for a trusted LAN.

See `ADDON_API.md` and `api/openapi-v1.json` for the public interface.

## Build and install

See `INSTALL.md`.

## Wiring

See `pinouts.md`.
