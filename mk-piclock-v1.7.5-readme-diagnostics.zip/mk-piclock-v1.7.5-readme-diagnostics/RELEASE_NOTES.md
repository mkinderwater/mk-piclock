# mk-piclock v1.7.5 Release Notes

## Safer OLED diagnostics gesture

- Holding the touch sensor for eight seconds opens the OLED network diagnostic screen.
- Releasing after a three-second hold but before eight seconds starts random music.
- Continuing to hold does not start music before diagnostics.
- A diagnostic hold is not counted toward the 10-tap Story Mode gesture.
- The diagnostic screen shows SSID, signal strength, IP address, and hostname.
- Tap to close it, or allow it to close automatically after 30 seconds.

## Features documented in README

- Simple optional plain-text web password
- Password prompt only when a password exists
- Optional short chime when an OLED message appears
- Fixed floating web confirmations visible at any scroll position
- Clean OLED song metadata that omits unsupported glyphs instead of showing question marks
- Original song title and artist retained in the GUI and API

## Versions

```text
Product:     1.7.5
HTTP API:    1.25
Private IPC: 16
```
