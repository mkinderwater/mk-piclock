export async function mount(ctx) {
    let fonts = null;
    const previewFaces = new Map();

    const applyStatus = status => {
        if (!status) return;
        const start = ctx.timeValue(status.bedtime_start_hour ?? 21, status.bedtime_start_min ?? 0);
        const end = ctx.timeValue(status.bedtime_end_hour ?? 7, status.bedtime_end_min ?? 0);
        const values = {
            '#clock-name': status.clock_name,
            '#bedtime-enabled': status.bedtime_enabled ? 1 : 0,
            '#bedtime-dim-percent': status.bedtime_dim_percent ?? 35,
            '#bedtime-start': start,
            '#bedtime-end': end,
            '#clock-24h-mode': status.clock_24h_mode ? 1 : 0,
            '#bed-oled-font-file': status.oled_font_file,
            '#bed-oled-font': status.oled_font ?? 0,
            '#bed-oled-font-size': status.oled_font_size ?? 48,
            '#bed-clock-24h-mode': status.clock_24h_mode ? 1 : 0,
            '#font-bedtime-enabled': status.bedtime_enabled ? 1 : 0,
            '#font-bedtime-start': start,
            '#font-bedtime-end': end,
            '#font-bedtime-dim-percent': status.bedtime_dim_percent ?? 35
        };
        Object.entries(values).forEach(([selector, value]) => ctx.setValue(selector, value));
        ctx.setText('#startup-name-preview', status.clock_name);
        ctx.setText('#startup-version-preview', status.app_version);
    };

    const fontFamily = name => `MKFont_${String(name).replace(/[^a-z0-9]/gi, '_')}`;
    const registerFont = name => {
        if (!name || previewFaces.has(name)) return fontFamily(name);
        const face = new FontFace(fontFamily(name), `url(/api/v1/assets/fonts/file?file=${encodeURIComponent(name)})`);
        previewFaces.set(name, face);
        document.fonts.add(face);
        face.load().catch(() => {});
        return fontFamily(name);
    };
    const sample = name => `<div class="font-sample-box" style="font-family:'${ctx.html(registerFont(name))}',sans-serif"><div>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div><div>1234567890</div></div>`;

    const updatePreview = () => {
        if (!fonts) return;
        const selected = ctx.$('#oled-font-file').value;
        if (selected) {
            ctx.$('#selected-font-preview').innerHTML = `<div class="font-preview-card"><div class="font-name">${ctx.html(selected)}</div>${sample(selected)}</div>`;
            ctx.setText('#selected-font', selected);
            return;
        }
        const id = Number.parseInt(ctx.$('#oled-font').value || fonts.builtin || 0, 10);
        const name = fonts.builtin_fonts?.find(font => font.id === id)?.name || 'Built-in';
        ctx.$('#selected-font-preview').innerHTML = `<div class="font-preview-card"><div class="font-name">${ctx.html(name)}</div><div class="font-sample-box builtin-sample"><div>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div><div>1234567890</div></div><div class="small muted">Built-in OLED font preview is approximated in the browser.</div></div>`;
        ctx.setText('#selected-font', name);
    };

    const loadFonts = async () => {
        fonts = await ctx.json('/api/v1/assets/fonts');
        ctx.setValue('#oled-font-size', fonts.font_size ?? 48);
        ctx.$('#oled-font-file').innerHTML = [
            '<option value="">Use built-in font</option>',
            ...(fonts.uploaded_fonts || []).map(name => `<option value="${ctx.html(name)}"${name === fonts.selected ? ' selected' : ''}>${ctx.html(name)}</option>`)
        ].join('');
        ctx.$('#oled-font').innerHTML = (fonts.builtin_fonts || []).map(font =>
            `<option value="${font.id}"${font.id === fonts.builtin ? ' selected' : ''}>${ctx.html(font.name)}</option>`
        ).join('');
        ctx.$('#delete-fonts').innerHTML = fonts.uploaded_fonts?.length
            ? fonts.uploaded_fonts.map(name => `
                <div class="mini-card font-delete-row">
                    <div><div class="font-name">${ctx.html(name)}</div>${sample(name)}</div>
                    <button class="btn danger small-btn" type="button" data-delete-font="${ctx.html(name)}">Delete</button>
                </div>`).join('')
            : '<p class="small">No uploaded fonts yet.</p>';
        updatePreview();
    };

    const refresh = async () => {
        const [statusResult, fontResult] = await Promise.allSettled([ctx.status.refresh(), loadFonts()]);
        if (statusResult.status === 'fulfilled') applyStatus(statusResult.value || ctx.status.get());
        if (fontResult.status === 'rejected') ctx.setText('#selected-font', 'Could not load fonts');
    };

    ctx.on('click', '[data-clock-action]', async (_, button) => {
        try { await ctx.clock(button.dataset.clockAction, {}, button); } catch (_) {}
    });
    ctx.on('change', '#oled-font-file, #oled-font', updatePreview);
    ctx.on('click', '[data-delete-font]', async (_, button) => {
        const name = button.dataset.deleteFont;
        if (!confirm(`Delete ${name}?`)) return;
        try {
            await ctx.update('/api/v1/assets/fonts/delete', {
                method: 'POST',
                body: new URLSearchParams({font: name, format: 'json'}),
                button,
                busyText: `Deleting ${name}...`,
                done: `Font deleted: ${name}`,
                errorText: `${name} could not be deleted`
            });
            await refresh();
        } catch (_) {}
    });

    ctx.signal.addEventListener('abort', () => {
        previewFaces.forEach(face => document.fonts.delete(face));
        previewFaces.clear();
    }, {once: true});

    await refresh();
    return {refresh};
}
