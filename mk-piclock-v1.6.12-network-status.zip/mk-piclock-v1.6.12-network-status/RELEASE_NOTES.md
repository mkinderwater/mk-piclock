# mk-piclock v1.6.12 Release Notes

Release package: `mk-piclock-v1.6.12-network-status.zip`

## Changes from v1.6.11

- Removed the global five-second status poll from the GUI shell.
- Automatic polling now runs only while the Dashboard module is open.
- Alarm, Display, Music, Message, Faces, and Log pages remain static while being edited.
- Display controls are no longer rewritten by status broadcasts.
- Music volume and metadata controls are no longer rewritten by status broadcasts.
- Music status still updates immediately after Play, Stop, upload, delete, or save actions.
- The clock name header updates after a saved configuration change without background polling.
- Retains the UTF-8 ID3 and OLED character handling introduced in v1.6.11.
- GUI cache versions were increased to prevent browsers from retaining the global-polling code.

## Compatibility

- Public API remains v1.0.
- Private core IPC remains binary IPC v4.
- Existing configuration and asset directories are unchanged.
- No new runtime libraries are required.

## Hardware

- GPIO assignments and wiring are unchanged from v1.6.11.
