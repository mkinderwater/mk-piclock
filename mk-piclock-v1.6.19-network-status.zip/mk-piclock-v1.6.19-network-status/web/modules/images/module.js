import {mountImageLibrary} from '/assets/js/image-library.js?v=175';

export function mount(ctx) {
    return mountImageLibrary(ctx, {
        heading: 'Images',
        labelSingular: 'Image',
        labelPlural: 'Images',
        description: 'Upload one or more PNG files. These images rotate during normal clock hours. The filename becomes the image title.',
        emptyText: 'No images yet. Upload PNG files above.',
        listUrl: '/api/v1/assets/images',
        uploadUrl: '/api/v1/assets/images/upload',
        deleteUrl: '/api/v1/assets/images/delete',
        deleteAllUrl: '/api/v1/assets/images/delete-all',
        allowShow: true,
        bedtime: false
    });
}
