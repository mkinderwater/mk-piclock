export async function mountImageLibrary(ctx, options) {
    let page = 1;
    const root = ctx.root;

    root.innerHTML = `
        <section class="panel image-library-module">
            <div class="card">
                <h2>${ctx.html(options.heading)}</h2>
                <p class="small">${ctx.html(options.description)}</p>
                <form method="POST" action="${ctx.html(options.uploadUrl)}" enctype="multipart/form-data"
                      class="upload-card"
                      data-busy-text="Uploading ${ctx.html(options.labelPlural.toLowerCase())}..."
                      data-success-text="${ctx.html(options.labelPlural)} uploaded and ready"
                      data-error-text="${ctx.html(options.labelSingular)} upload failed">
                    <label>${ctx.html(options.labelPlural)} PNG files</label>
                    <input type="file" name="files" accept="image/png,.png" multiple>
                    <button class="btn${options.bedtime ? ' alt' : ''}" type="submit">Upload ${ctx.html(options.labelPlural)}</button>
                </form>
                <div class="danger-zone inline-danger-zone">
                    <button class="btn danger" type="button" id="delete-all-images">Delete All ${ctx.html(options.labelPlural)}</button>
                    <span class="small muted">Removes this library's OLED data and saved source PNGs.</span>
                </div>
                <div class="field-row">
                    <div>
                        <label for="image-page-select">Page</label>
                        <select id="image-page-select"></select>
                    </div>
                    <div>
                        <label for="image-count">Uploaded</label>
                        <input id="image-count" type="text" value="Loading..." readonly>
                    </div>
                </div>
            </div>
            <div id="image-list" class="cards"></div>
        </section>`;

    const renderCards = images => {
        const target = ctx.$('#image-list');
        if (!images.length) {
            target.innerHTML = `<div class="card"><p>${ctx.html(options.emptyText)}</p></div>`;
            return;
        }
        target.innerHTML = images.map(image => `
            <div class="card image-card" data-file="${ctx.html(image.file)}">
                <div class="card-title-row"><h2>${ctx.html(image.title || image.file)}</h2><span class="badge ok">Uploaded</span></div>
                <div class="image-card-layout">
                    ${image.preview_url
                        ? `<img class="image-preview-img" src="${ctx.html(image.preview_url)}" alt="${ctx.html(image.title || image.file)}">`
                        : '<div class="image-preview-missing">RAW</div>'}
                    <div>
                        <p class="small mono ${image.source_png ? '' : 'muted'}">${image.source_png ? `Source PNG: ${ctx.html(image.source_png)}` : 'Source PNG not available'}</p>
                        <p class="small mono">OLED RAW: ${ctx.html(image.file)}</p>
                        <div class="image-actions">
                            ${options.allowShow ? `<button class="btn alt" type="button" data-image-show="${ctx.html(image.file)}" data-image-title="${ctx.html(image.title || image.file)}">Show Image</button>` : ''}
                            <button class="btn danger" type="button" data-image-delete="${ctx.html(image.file)}">Delete</button>
                        </div>
                    </div>
                </div>
            </div>`).join('');
    };

    const refresh = async () => {
        try {
            const data = await ctx.json(`${options.listUrl}?page=${page}`);
            page = data.page || 1;
            const pageCount = data.max_page || 1;
            ctx.$('#image-page-select').innerHTML = Array.from({length: pageCount}, (_, index) => {
                const value = index + 1;
                return `<option value="${value}"${value === page ? ' selected' : ''}>Page ${value}</option>`;
            }).join('');
            ctx.setValue('#image-count', data.count ? `${data.count} uploaded` : 'None uploaded');
            renderCards(data.images || []);
        } catch (_) {
            ctx.setValue('#image-count', 'Could not load');
            ctx.$('#image-list').innerHTML = `<div class="card"><p>${ctx.html(options.labelPlural)} could not be loaded.</p></div>`;
        }
    };

    ctx.on('change', '#image-page-select', (_, select) => {
        page = Number.parseInt(select.value || '1', 10);
        refresh();
    });

    if (options.allowShow) {
        ctx.on('click', '[data-image-show]', async (_, button) => {
            const title = button.dataset.imageTitle || button.dataset.imageShow;
            try {
                await ctx.update('/api/v1/display/image', {
                    method: 'POST',
                    body: new URLSearchParams({file: button.dataset.imageShow, format: 'json'}),
                    button,
                    busyText: `Showing ${title}...`,
                    done: `Showing ${title} on the OLED`,
                    errorText: `${title} could not be shown`
                });
            } catch (_) {}
        });
    }

    ctx.on('click', '[data-image-delete]', async (_, button) => {
        const file = button.dataset.imageDelete;
        if (!file || !confirm(`Delete ${file}?`)) return;
        try {
            await ctx.update(options.deleteUrl, {
                method: 'POST',
                body: new URLSearchParams({file, format: 'json'}),
                button,
                busyText: `Deleting ${file}...`,
                done: `${options.labelSingular} deleted: ${file}`,
                errorText: `${file} could not be deleted`
            });
            await refresh();
        } catch (_) {}
    });

    ctx.on('click', '#delete-all-images', async (_, button) => {
        if (!confirm(`Delete ALL ${options.labelPlural.toLowerCase()}, including saved source PNGs?`)) return;
        try {
            await ctx.update(options.deleteAllUrl, {
                method: 'POST',
                body: new URLSearchParams({format: 'json'}),
                button,
                busyText: `Deleting all ${options.labelPlural.toLowerCase()}...`,
                done: `All ${options.labelPlural.toLowerCase()} deleted`,
                errorText: `${options.labelSingular} library could not be cleared`
            });
            page = 1;
            await refresh();
        } catch (_) {}
    });

    await refresh();
    return {refresh};
}
