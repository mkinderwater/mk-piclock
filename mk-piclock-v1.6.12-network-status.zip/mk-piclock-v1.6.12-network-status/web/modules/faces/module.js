export async function mount(ctx) {
    let page = 1;

    const renderCards = (target, faces, emptyText, allowShow, kind) => {
        if (!faces.length) {
            target.innerHTML = `<div class="card"><p>${ctx.html(emptyText)}</p></div>`;
            return;
        }
        target.innerHTML = faces.map(face => `
            <div class="card face-card" data-file="${ctx.html(face.file)}" data-kind="${kind}">
                <div class="card-title-row"><h2>${ctx.html(face.title || face.file)}</h2><span class="badge ok">Uploaded</span></div>
                <div class="face-card-layout">
                    ${face.preview_url
                        ? `<img class="face-preview-img" src="${ctx.html(face.preview_url)}" alt="${ctx.html(face.title || face.file)}">`
                        : '<div class="face-preview-missing">RAW</div>'}
                    <div>
                        <p class="small mono ${face.source_png ? '' : 'muted'}">${face.source_png ? `Source PNG: ${ctx.html(face.source_png)}` : 'Source PNG not available'}</p>
                        <p class="small mono">OLED RAW: ${ctx.html(face.file)}</p>
                        <div class="face-actions">
                            ${allowShow ? `<button class="btn alt" type="button" data-face-show="${ctx.html(face.file)}" data-face-title="${ctx.html(face.title || face.file)}">Show Face</button>` : ''}
                            <button class="btn danger" type="button" data-face-delete="${ctx.html(face.file)}" data-kind="${kind}">Delete</button>
                        </div>
                    </div>
                </div>
            </div>`).join('');
    };

    const loadNormal = async () => {
        const data = await ctx.json(`/api/v1/assets/faces?page=${page}`);
        page = data.page || 1;
        ctx.$('#face-page-select').innerHTML = Array.from({length: data.max_page || 1}, (_, index) => {
            const current = index + 1;
            return `<option value="${current}"${current === page ? ' selected' : ''}>Page ${current}</option>`;
        }).join('');
        ctx.setValue('#face-count', data.count ? `${data.count} uploaded` : 'No faces uploaded');
        renderCards(ctx.$('#face-list'), data.faces || [], 'No normal faces yet. Upload PNG files above.', true, 'normal');
    };

    const loadBedtime = async () => {
        const data = await ctx.json('/api/v1/assets/faces?kind=bedtime&all=1');
        ctx.setText('#bedtime-face-count', data.count ? `${data.count} uploaded` : 'No bedtime faces uploaded');
        renderCards(ctx.$('#bedtime-face-list'), data.faces || [], 'No bedtime faces yet. Upload PNG files above.', false, 'bedtime');
    };

    const refresh = async () => {
        const [normal, bedtime] = await Promise.allSettled([loadNormal(), loadBedtime()]);
        if (normal.status === 'rejected') ctx.$('#face-list').innerHTML = '<div class="card"><p>Could not load normal faces.</p></div>';
        if (bedtime.status === 'rejected') {
            ctx.setText('#bedtime-face-count', 'Could not load');
            ctx.$('#bedtime-face-list').innerHTML = '<div class="card"><p>Could not load bedtime faces.</p></div>';
        }
    };

    ctx.on('change', '#face-page-select', (_, select) => {
        page = Number.parseInt(select.value || '1', 10);
        refresh();
    });
    ctx.on('click', '[data-face-show]', async (_, button) => {
        const title = button.dataset.faceTitle || button.dataset.faceShow;
        const body = new URLSearchParams({file: button.dataset.faceShow, format: 'json'});
        try {
            await ctx.update('/api/v1/display/face', {
                method: 'POST',
                body,
                button,
                busyText: `Showing ${title}...`,
                done: `Showing ${title} on the OLED`,
                errorText: `${title} could not be shown`
            });
        } catch (_) {}
    });
    ctx.on('click', '[data-face-delete]', async (_, button) => {
        const file = button.dataset.faceDelete;
        if (!file || !confirm(`Delete ${file}?`)) return;
        try {
            await ctx.update('/api/v1/assets/faces/delete', {
                method: 'POST',
                body: new URLSearchParams({file, kind: button.dataset.kind || 'normal', format: 'json'}),
                button,
                busyText: `Deleting ${file}...`,
                done: `Face deleted: ${file}`,
                errorText: `${file} could not be deleted`
            });
            await refresh();
        } catch (_) {}
    });
    ctx.on('click', '#delete-all-faces', async (_, button) => {
        if (!confirm('Delete ALL normal and bedtime faces, including saved source PNGs?')) return;
        try {
            await ctx.update('/api/v1/assets/faces/delete-all', {
                method: 'POST',
                body: new URLSearchParams({format: 'json'}),
                button,
                busyText: 'Deleting all faces...',
                done: 'All normal and bedtime faces deleted',
                errorText: 'Face library could not be cleared'
            });
            page = 1;
            await refresh();
        } catch (_) {}
    });

    await refresh();
    return {refresh};
}
