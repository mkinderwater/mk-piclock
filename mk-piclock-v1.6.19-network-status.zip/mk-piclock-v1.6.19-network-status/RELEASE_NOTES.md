# mk-piclock v1.6.19 Release Notes

## Images and storage

- Renamed the GUI feature from Faces to Images.
- Added separate Images and Bedtime Images menu pages.
- Added independent upload, paging, count, delete, and delete-all controls.
- Changed storage to `/assets/images` and `/assets/bedtime-images`.
- Removed migration logic and old face-directory compatibility.

## OLED colour

- Added Yellow, Green, and White panel choices under Display.
- Dashboard, message, and font previews use the selected colour.
- The physical panel colour remains hardware-defined.

## Code cull

- Removed numeric image IDs from state, IPC, API responses, and `face_001.raw` compatibility.
- Removed the unused full-screen image display mode.
- Removed old single-alarm configuration aliases.
- Removed the old `web_font` alias.
- Removed duplicate music `files` output. Music now returns `tracks` only.
- Removed old message form aliases.
- Consolidated both image pages on one shared JavaScript library and shared styles.
- Removed a duplicate `clock` action test.
- Corrected normal and bedtime cache invalidation so each library reloads independently.

## Compatibility

- Product version: 1.6.19
- Public API version: 1.1
- Private core IPC version: 6
- Install the core and API together.
- Re-add artwork to the new image directories.
