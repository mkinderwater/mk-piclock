export async function mount(ctx) {
    const renderStatus = status => {
        if (!status) return;
        ctx.setText('#music-status', status.audio_playing ? 'Playing' : 'Stopped');
        const metadata = [status.audio_title, status.audio_artist].filter(Boolean).join(' - ');
        ctx.setText('#music-current', metadata || status.audio_file || '-');
        ctx.setValue('#global-volume', status.global_volume ?? 80);
        ctx.setValue('#show-song-metadata', status.show_song_metadata ? 1 : 0);
    };

    const refreshLibrary = async () => {
        try {
            const data = await ctx.json('/api/v1/assets/music');
            const tracks = data.tracks || [];
            ctx.setText('#music-count', tracks.length);
            ctx.setValue('#global-volume', data.global_volume ?? 80);
            ctx.$('#music-list').innerHTML = tracks.length
                ? tracks.map(track => `
                    <div class="mini-card song-card">
                        <div class="song-details">
                            <div class="font-name">${ctx.html(track.display || track.title || track.file)}</div>
                            <div class="small muted">${ctx.html(track.file)}${track.id3 ? ' · ID3' : ''}</div>
                        </div>
                        <div class="mini-actions">
                            <button class="btn ok small-btn" type="button" data-music-play="${ctx.html(track.file)}" data-music-label="${ctx.html(track.display || track.title || track.file)}">Play</button>
                            <button class="btn danger small-btn" type="button" data-music-stop>Stop</button>
                        </div>
                    </div>`).join('')
                : '<p class="small">No uploaded MP3 files yet.</p>';
        } catch (_) {
            ctx.$('#music-list').innerHTML = '<p class="small">Could not load music.</p>';
        }
    };

    ctx.on('click', '[data-music-play]', async (_, button) => {
        try {
            const label = button.dataset.musicLabel || button.dataset.musicPlay;
            await ctx.clock('play-music', {file: button.dataset.musicPlay}, button, {
                busyText: `Starting ${label}...`,
                done: `Playing ${label}`,
                errorText: `${label} could not be played`
            });
            renderStatus(ctx.status.get());
        } catch (_) {}
    });
    ctx.on('click', '[data-music-stop]', async (_, button) => {
        try {
            await ctx.clock('stop', {}, button);
            renderStatus(ctx.status.get());
        } catch (_) {}
    });
    ctx.on('click', '#delete-all-music', async (_, button) => {
        if (!confirm('Delete ALL uploaded MP3 files and reset alarm music choices to Random?')) return;
        try {
            await ctx.update('/api/v1/assets/music/delete-all', {
                method: 'POST',
                body: new URLSearchParams({format: 'json'}),
                button,
                busyText: 'Deleting all music...',
                done: 'All uploaded music deleted',
                errorText: 'Music library could not be cleared'
            });
            await refresh();
        } catch (_) {}
    });

    const refresh = async () => {
        const [statusResult] = await Promise.allSettled([ctx.status.refresh(), refreshLibrary()]);
        if (statusResult.status === 'fulfilled') renderStatus(statusResult.value || ctx.status.get());
    };

    await refresh();
    return {refresh};
}
