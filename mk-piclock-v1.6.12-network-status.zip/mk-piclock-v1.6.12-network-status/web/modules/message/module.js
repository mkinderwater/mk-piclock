export async function mount(ctx) {
    let fitTimer = null;
    let fitSequence = 0;
    let limit = {max_chars: 180, max_lines: 3};
    let faces = [];
    let activeFont = null;
    let activeFontKey = '';

    const sendStatus = (text = '', type = '') => {
        const node = ctx.$('#message-send-status');
        node.textContent = text;
        node.className = `message-send-status ${type}`;
        node.classList.toggle('hidden', !text);
    };

    const renderPending = status => {
        if (!status?.message_pending) {
            ctx.setText('#message-pending', 'No delayed message pending.');
            return;
        }
        const seconds = Math.max(0, Number.parseInt(status.message_send_in_seconds || 0, 10));
        ctx.setText('#message-pending', `Delayed message due in about ${seconds} seconds.`);
    };

    const previewFont = status => {
        if (!status) return;
        const box = ctx.$('#message-text');
        box.style.fontSize = `${Math.max(13, Math.min(23, Math.round(Math.min(18, status.oled_font_size || 18) * 1.18)))}px`;

        const key = status.oled_font_file || `builtin:${status.oled_font_name || ''}`;
        if (key === activeFontKey) return;
        activeFontKey = key;

        if (activeFont) document.fonts.delete(activeFont);
        activeFont = null;

        if (status.oled_font_file) {
            const family = `MKMessage_${status.oled_font_file.replace(/[^a-z0-9]/gi, '_')}`;
            activeFont = new FontFace(family, `url(/api/v1/assets/fonts/file?file=${encodeURIComponent(status.oled_font_file)})`);
            document.fonts.add(activeFont);
            activeFont.load().catch(() => {});
            box.style.fontFamily = `"${family}", system-ui, sans-serif`;
            ctx.setText('#message-font-hint', `Input font: ${status.oled_font_file}`);
        } else {
            box.style.fontFamily = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
            ctx.setText('#message-font-hint', `Input font: ${status.oled_font_name || 'built-in OLED font'} (browser approximation)`);
        }
    };

    const updateFace = () => {
        const selected = ctx.$('#message-face-file').value;
        const face = faces.find(item => item.file === selected);
        const image = ctx.$('#message-oled-face');
        const missing = ctx.$('#message-oled-face-missing');
        if (face?.preview_url) {
            image.src = face.preview_url;
            image.alt = face.title || face.file;
            image.classList.remove('hidden');
            missing.classList.add('hidden');
        } else {
            image.removeAttribute('src');
            image.classList.add('hidden');
            missing.classList.remove('hidden');
        }
    };

    const centerText = (lines = 1) => {
        const box = ctx.$('#message-text');
        const style = getComputedStyle(box);
        const lineHeight = Number.parseFloat(style.lineHeight) || Number.parseFloat(style.fontSize) * 1.08;
        const padding = Math.max(5, Math.round((box.clientHeight - Math.min(3, Math.max(1, lines)) * lineHeight) / 2));
        box.style.paddingTop = `${padding}px`;
        box.style.paddingBottom = `${padding}px`;
    };

    const updateCounter = () => {
        ctx.setText('#message-counter', `${ctx.$('#message-text').value.length} / ${limit.max_chars || 180}`);
    };

    const checkFit = async () => {
        const box = ctx.$('#message-text');
        const fitNode = ctx.$('#message-fit-status');
        const submit = ctx.$('#message-submit');
        const text = box.value || '';
        const sequence = ++fitSequence;
        updateCounter();

        if (!text.trim()) {
            fitNode.textContent = 'Enter a message. Fit is checked against the OLED layout.';
            fitNode.className = 'muted';
            submit.disabled = false;
            centerText(1);
            return;
        }
        if (text.length > limit.max_chars) {
            fitNode.textContent = 'Too long for screen';
            fitNode.className = 'warn-text';
            submit.disabled = true;
            return;
        }

        try {
            const fit = await ctx.json(`/api/v1/display/message/fit?text=${encodeURIComponent(text)}`);
            if (ctx.signal.aborted || sequence !== fitSequence || box.value !== text) return;
            fitNode.textContent = fit.ok ? 'Fits screen with wrap' : (fit.reason || 'Too long for screen');
            fitNode.className = fit.ok ? 'ok-text' : 'warn-text';
            submit.disabled = !fit.ok;
            centerText(fit.line_count || fit.lines?.length || 1);
        } catch (_) {
            fitNode.textContent = 'Limit check unavailable';
            fitNode.className = 'muted';
            submit.disabled = false;
        }
    };

    const scheduleFit = () => {
        updateCounter();
        clearTimeout(fitTimer);
        fitTimer = window.setTimeout(checkFit, 220);
    };

    const loadFaces = async () => {
        try {
            faces = (await ctx.json('/api/v1/assets/faces?all=1')).faces || [];
        } catch (_) {
            faces = [];
        }
        ctx.$('#message-face-file').innerHTML = faces.length
            ? faces.map(face => `<option value="${ctx.html(face.file)}">${ctx.html(face.title || face.file)}</option>`).join('')
            : '<option value="">No uploaded faces</option>';
        updateFace();
    };

    const loadLimit = async () => {
        try {
            limit = await ctx.json('/api/v1/display/message/limits');
        } catch (_) {
            limit = {max_chars: 180, max_lines: 3};
        }
        ctx.$('#message-text').maxLength = limit.max_chars || 180;
        updateCounter();
    };

    ctx.status.subscribe(previewFont);
    ctx.status.subscribe(renderPending);
    ctx.on('input', '#message-text', scheduleFit);
    ctx.on('change', '#message-face-file', updateFace);
    ctx.on('change', '#message-delay', (_, select) => {
        ctx.setText('#message-submit', select.value === '0' ? 'Send to Clock' : 'Schedule Message');
    });
    ctx.on('click', '#message-clear', () => {
        ctx.setValue('#message-text', '');
        sendStatus('Message draft cleared.', 'ok');
        scheduleFit();
        ctx.$('#message-text').focus();
    });
    ctx.on('submit', '#message-form', async (event, form) => {
        event.preventDefault();
        const button = ctx.$('#message-submit');
        const delay = Number.parseInt(ctx.$('#message-delay').value || '0', 10);
        const body = new URLSearchParams(new FormData(form));
        body.set('format', 'json');
        sendStatus();
        try {
            await ctx.update(form.action, {
                method: 'POST',
                body,
                button,
                busyText: delay > 0 ? 'Scheduling message...' : 'Sending message...',
                done: delay > 0 ? `Message scheduled in ${delay} seconds` : 'Message shown on OLED',
                errorText: delay > 0 ? 'Message could not be scheduled' : 'Message could not be shown'
            });
            ctx.setValue('#message-text', '');
            await checkFit();
            sendStatus(delay > 0
                ? `Message scheduled for ${delay} seconds from now.`
                : 'Sent to the clock. Ready for the next message.', 'ok');
            ctx.$('#message-text').focus();
        } catch (error) {
            sendStatus(error.message || 'Message was not sent.', 'warn');
        }
    });

    ctx.signal.addEventListener('abort', () => {
        clearTimeout(fitTimer);
        if (activeFont) document.fonts.delete(activeFont);
    }, {once: true});

    await Promise.all([ctx.status.refresh(), loadLimit(), loadFaces()]);
    previewFont(ctx.status.get());
    scheduleFit();
}
