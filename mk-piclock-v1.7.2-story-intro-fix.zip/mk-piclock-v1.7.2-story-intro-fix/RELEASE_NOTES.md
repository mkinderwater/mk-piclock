# mk-piclock v1.7.2 Release Notes

## Touch lighting and batch MP3 uploads

This release keeps touch-sensor LED feedback and replaces the MP3 upload queue with the cleaner atomic batch queue.

### Changes

- Pressing the touch sensor now blinks the RGB LED.
- The blink defaults to white and can be changed under Lighting, Global Controls.
- The Music page now accepts multiple MP3 files in one upload.
- New music uploads remain blocked until all queued and processing MP3 jobs are complete.
- The full MP3 selection is validated, staged, and queued as one batch.
- A staging or queue failure rolls back the whole batch instead of leaving a partial upload.
- The Music page shows a selected-file count and total size before upload.
- The stable trailing-edge LED PWM driver from v1.6.57 is retained.
- Installer and runtime directory creation was audited; only required storage, web/API, config, and socket directories are created.

Hardware mapping remains:

- Red: GPIO5, physical pin 29
- Green: GPIO6, physical pin 31
- Blue: GPIO13, physical pin 33
- Common cathode: ground

## Versions

```text
Product:     1.7.2
HTTP API:    1.24
Private IPC: 15
```
