# mk-piclock v1.6.39 Release Notes

## Complete GUI asset replacement

This release corrects the incomplete cleanup in v1.6.38.

`make install` previously deleted only visible children under `/opt/mk-piclock/web`. The installed web and API documentation trees are now removed and recreated before the current release is copied into place. This removes hidden files, retired modules, and superseded static assets.

## Changes

- Stop `mk-piclock-api` before replacing the GUI.
- Recreate `/opt/mk-piclock/web` and `/opt/mk-piclock/api` from scratch.
- Preserve user images, bedtime images, music, fonts, and configuration.
- Disable browser caching for every GUI file, including icons and the favicon.
- Add v1.6.39 revision keys to all GUI asset references.
- Remove the unused 48x48 favicon.
- Remove installed GUI and API documentation trees during uninstall.

## Compatibility

```text
Product:     1.6.39
HTTP API:    1.16
Private IPC: 11
```
