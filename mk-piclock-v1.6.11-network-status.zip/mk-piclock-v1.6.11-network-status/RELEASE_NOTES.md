# mk-piclock v1.6.11 Release Notes

Release package: `mk-piclock-v1.6.11-network-status.zip`

## Changes from v1.6.10

- Alarm forms no longer re-render during the five-second status poll. Values being edited are left untouched until the user saves or leaves the page.
- The sticky GUI header now identifies the configured clock as `Editing: <clock name>` on every page.
- The browser tab also includes the configured clock name.
- UTF-8 ID3 title and artist data is decoded before conversion to the OLED's compact 5x7 character set.
- The 5x7 OLED renderer now reads UTF-8 code points. Common umlauts use dedicated glyphs, while other accented Latin characters and smart punctuation use readable OLED-safe glyphs instead of `?`. For example, `Yoü and I` displays as `YOÜ AND I`.
- The Music page and public API continue to return the original UTF-8 metadata, including accents.
- GUI cache versions were increased to prevent a browser from retaining the earlier alarm and header JavaScript.

## Compatibility

- Public API remains v1.0.
- Private core IPC remains binary IPC v4.
- Existing configuration and asset directories are unchanged.
- No new runtime libraries are required.

## Hardware

- GPIO assignments and wiring are unchanged from v1.6.10.
