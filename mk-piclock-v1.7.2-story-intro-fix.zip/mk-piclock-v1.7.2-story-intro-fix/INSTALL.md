# mk-piclock v1.7.2: Build and Install

## Supported target

Use Raspberry Pi OS Lite based on Debian 13 Trixie. The source uses the libgpiod 2.x API.

Recommended builds:

- Raspberry Pi Zero 2 W: `make -j2`
- Raspberry Pi 5: `make -j4`

Confirm the OS:

```bash
cat /etc/os-release
```

## 1. Verify and extract the release

Place the ZIP and checksum file in the same directory, then run:

```bash
cd ~
sha256sum -c mk-piclock-v1.7.2-touch-lighting-multi-upload-mp3-clean.zip.sha256
rm -rf mk-piclock-v1.7.2-touch-lighting-multi-upload-mp3-clean
unzip mk-piclock-v1.7.2-touch-lighting-multi-upload-mp3-clean.zip
cd mk-piclock-v1.7.2-touch-lighting-multi-upload-mp3-clean
```

## 2. Install dependencies

```bash
sudo apt update
sudo apt install --no-install-recommends -y \
  build-essential \
  pkg-config \
  libgpiod-dev \
  gpiod \
  libpng-dev \
  libfreetype-dev \
  libasound2-dev \
  libmpg123-dev \
  libmp3lame-dev \
  libmicrohttpd-dev \
  alsa-utils \
  unzip \
  curl
```

Confirm libgpiod 2.x:

```bash
pkg-config --modversion libgpiod
```

## 3. Configure boot hardware

Edit:

```bash
sudo nano /boot/firmware/config.txt
```

Ensure these entries exist once:

```ini
dtparam=spi=on
dtparam=audio=off
dtoverlay=max98357a,no-sdmode
gpu_mem=16
```

Reboot:

```bash
sudo reboot
```

## 4. Verify interfaces

```bash
ls -l /dev/spidev0.0 /dev/gpiochip0
gpiodetect
aplay -l
```

The core expects:

```text
SPI:       /dev/spidev0.0
GPIO chip: /dev/gpiochip0
OLED DC:   GPIO25, physical pin 22
OLED RST:  GPIO27, physical pin 13
Touch OUT: GPIO20, physical pin 38
LED red:   GPIO5, physical pin 29
LED green: GPIO6, physical pin 31
LED blue:  GPIO13, physical pin 33
Audio:     ALSA device default
```

See `pinouts.md` before applying power.

## 5. Build

Pi Zero 2 W:

```bash
make clean
make -j2
```

Pi 5:

```bash
make clean
make -j4
```

Confirm both binaries:

```bash
ls -lh mk-piclock-core mk-piclock-api
```

## 6. Install

```bash
make install
sudo systemctl restart mk-piclock-core.service mk-piclock-api.service
```

Do not prefix `make install` with `sudo`. The Makefile invokes `sudo` for privileged steps.

The clean install creates:

```text
/opt/mk-piclock/assets/images
/opt/mk-piclock/assets/bedtime-images
/opt/mk-piclock/assets/music
/opt/mk-piclock/assets/music/.processing
/opt/mk-piclock/assets/stories
/opt/mk-piclock/assets/fonts
/opt/mk-piclock/assets/default-alarm.mp3
/opt/mk-piclock/config
/opt/mk-piclock/web
/opt/mk-piclock/api
/run/mk-piclock
```

All listed directories are required. Old `auth`, `faces`, `bedtime-faces`, and `bedtime_faces` directories are not created. Re-add normal and bedtime artwork through their new GUI pages or copy it into the new directories before restarting the services.

## 7. Verify

```bash
sudo systemctl --no-pager --full status \
  mk-piclock-core.service \
  mk-piclock-api.service

curl -s http://127.0.0.1:8080/api/v1/status
```

Open:

```text
http://<clock-ip>:8080/
```

The controls open immediately. Keep port 8080 on a trusted home network.

Expected GUI pages:

```text
Home
Alarms
Messages
Music
Stories
Day Images
Bedtime Images
Display
System
Recent Activity
```

## 8. Initial configuration

1. Open Display and set the clock name.
2. Select Yellow, Green, or White to match the physical OLED panel.
3. Configure bedtime start, end, brightness, and whether touch music is allowed at night.
4. Upload normal artwork under Day Images.
5. Upload night artwork under Bedtime Images.
6. Upload songs under Music and story MP3 files under Stories.
7. Enable Story Mode, set its volume and intro text, then configure alarm slots.
8. Open Lighting, choose the six activity profiles, and use Preview to verify the RGB wiring.
9. Open System and confirm NTP, network, Raspberry Pi model, operating system, SD card, touch, OLED, and service health.
10. Download an initial backup. Uploaded music and stories are excluded and must be copied separately if required.

The OLED panel colour selector on the Display page affects browser previews only. The physical OLED colour cannot be changed in software. Lighting colour selections control the RGB LED.

## 9. Re-add existing image assets

The recommended method is to upload source PNG files through Images and Bedtime Images so the API creates matching OLED `.raw` files.

Existing converted artwork can be copied only when each image has both files with the same base name:

```text
example.png
example.raw
```

Copy paired files into the matching new directory, then restore ownership and restart both services:

```bash
sudo systemctl stop mk-piclock-core.service mk-piclock-api.service
sudo cp normal/* /opt/mk-piclock/assets/images/
sudo cp bedtime/* /opt/mk-piclock/assets/bedtime-images/
sudo chown -R mk-piclock-api:mk-piclock /opt/mk-piclock/assets
sudo chmod -R u=rwX,g=rX,o= /opt/mk-piclock/assets
sudo systemctl start mk-piclock-core.service mk-piclock-api.service
```

A PNG without its converted raw partner appears in neither image library nor the OLED rotation.

## 10. Logs

```bash
sudo journalctl -b -u mk-piclock-core.service -n 100 --no-pager
sudo journalctl -b -u mk-piclock-api.service -n 100 --no-pager
```

Follow both:

```bash
sudo journalctl -f -u mk-piclock-core.service -u mk-piclock-api.service
```

## Troubleshooting

### API unavailable

```bash
sudo systemctl restart mk-piclock-core mk-piclock-api
sudo journalctl -b -u mk-piclock-api -n 100 --no-pager
```

### OLED unavailable

```bash
ls -l /dev/spidev0.0 /dev/gpiochip0
id mk-piclock-core
```

Confirm SPI is enabled and the service user belongs to the required hardware groups.

### No audio

```bash
aplay -l
speaker-test -D default -c 2 -t sine
```

Stop the test with `Ctrl+C`.

### Build header missing

Install the matching development package, run `make clean`, then rebuild. Common packages are `libmicrohttpd-dev`, `libgpiod-dev`, `libasound2-dev`, `libmpg123-dev`, `libmp3lame-dev`, `libfreetype-dev`, and `libpng-dev`.
