# mk-piclock HTTP API 1.1

The GUI and add-ons use the HTTP API on port 8080.

```text
http://<clock-ip>:8080/api/v1
```

The API has no authentication. Use it only on a trusted LAN.

## Discovery

```http
GET /api/v1
GET /api/v1/capabilities
GET /api/v1/openapi.json
GET /api/v1/health
GET /api/v1/status
```

`/status` returns the current clock, display, brightness, bedtime, audio, touch, message, image, font, and alarm state. Consumers should ignore unknown fields.

## Images

Normal and bedtime images are separate resources.

```http
GET  /api/v1/assets/images
GET  /api/v1/assets/bedtime-images
GET  /api/v1/assets/images/source?file=<raw-name>
GET  /api/v1/assets/bedtime-images/source?file=<raw-name>
POST /api/v1/assets/images/upload
POST /api/v1/assets/bedtime-images/upload
POST /api/v1/assets/images/delete
POST /api/v1/assets/bedtime-images/delete
POST /api/v1/assets/images/delete-all
POST /api/v1/assets/bedtime-images/delete-all
```

List query parameters:

```text
page=<1-based page>
all=1
```

Upload one or more PNG files as multipart form field `files`. The response list uses `images`, not `faces`.

Show a normal image for 15 seconds:

```bash
curl -s \
  --data-urlencode 'file=happy.raw' \
  http://clock:8080/api/v1/display/image
```

Delete one normal image:

```bash
curl -s \
  --data-urlencode 'file=happy.raw' \
  http://clock:8080/api/v1/assets/images/delete
```

## Music

```http
GET  /api/v1/assets/music
POST /api/v1/assets/music/upload
POST /api/v1/assets/music/delete-all
```

The list response contains:

```json
{
  "global_volume": 80,
  "current": "song.mp3",
  "tracks": [
    {
      "file": "song.mp3",
      "title": "Title",
      "artist": "Artist",
      "display": "Title - Artist",
      "id3": 1
    }
  ]
}
```

Upload MP3 files as multipart form field `file`.

Play a track:

```bash
curl -s \
  --data 'do=play-music' \
  --data-urlencode 'file=song.mp3' \
  http://clock:8080/api/v1/display/action
```

Stop audio:

```bash
curl -s --data 'do=stop' http://clock:8080/api/v1/display/action
```

## Fonts

```http
GET  /api/v1/assets/fonts
GET  /api/v1/assets/fonts/file?file=<font-name>
POST /api/v1/assets/fonts/upload
POST /api/v1/assets/fonts/delete
```

Upload one TTF or OTF file as multipart field `file`.

## Display

```http
POST /api/v1/display/action
GET  /api/v1/display/preview
POST /api/v1/display/brightness-preview
POST /api/v1/display/image
POST /api/v1/display/message
GET  /api/v1/display/message/limits
GET  /api/v1/display/message/fit?text=<text>
```

Display actions:

```text
do=clock
do=clear
do=stop
do=play-music&file=<mp3>
```

Brightness preview fields:

```text
brightness_percent=0..100
hold_seconds=1..30
```

Messages accept:

```text
image_file=<normal image raw filename, optional>
message_text=<text>
delay_seconds=0, 10, 30, or 60
```

No numeric image ID or old message alias is accepted.

The framebuffer preview endpoint returns the packed 256x64 OLED buffer and its current display state. The built-in Dashboard is the reference client.

## Configuration

```http
POST /api/v1/config/alarms
POST /api/v1/config/audio
POST /api/v1/config/personalization
POST /api/v1/config/display
```

Alarm fields:

```text
id=1..7
enabled=0|1
time=HH:MM
day0..day6=1
music_file=<mp3>
start_volume=0..100
end_volume=0..100
```

Audio fields are optional and may be sent independently:

```text
global_volume=0..100
show_song_metadata=0|1
```

Personalization:

```text
clock_name=<name>
```

Display fields are optional:

```text
oled_font=0..3
oled_font_file=<font filename or empty>
oled_font_size=18..54
clock_24h_mode=0|1
oled_color=yellow|green|white
bedtime_enabled=0|1
bedtime_dim_percent=0..100
bedtime_start=HH:MM
bedtime_end=HH:MM
```

The OLED colour identifies the installed panel for browser previews. It does not change the physical panel colour.

## Logs

```http
GET  /api/v1/logs
POST /api/v1/logs/clear
```

## Compatibility changes in API 1.1

- `faces` routes and fields were removed.
- Normal and bedtime image routes are separate.
- Image selection uses filenames only.
- Music lists return `tracks` only.
- Old message aliases were removed.
- The core and API use private IPC version 6 and must be installed together.
