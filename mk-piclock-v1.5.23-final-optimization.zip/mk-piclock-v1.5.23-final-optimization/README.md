# mk-piclock-c v1.5.23

Native C Raspberry Pi alarm clock daemon for a 256x64 SSD1322 grayscale OLED. It includes a built-in web GUI, uploaded PNG faces, bedtime-only faces, TrueType/OpenType clock fonts, message display, MP3 alarms with volume ramping, OLED dimming, and I2S audio through a MAX98357A DAC/amp.

## What changed in v1.5.23

- Final optimization pass before project freeze.
- Added a RAM cache for the active 64x64 raw face image.
  - Normal and bedtime face uploads/deletes explicitly invalidate the cache.
  - This reduces repeated microSD reads during normal screen redraws.
- Added cached asset lists for faces, bedtime faces, music, and fonts.
  - Upload/delete paths mark the relevant list dirty.
  - API list calls and random music/face picks avoid repeated directory scans.
- Added an HTTP worker cap.
  - Maximum concurrent GUI request workers defaults to 8.
  - Extra clients are rejected instead of creating unlimited detached threads.
- Removed per-client socket handoff allocation.
  - The accepted socket fd is passed directly through `intptr_t`.
- Made config writes atomic.
  - `save_config()` now writes `clock.conf.tmp`, flushes, fsyncs, then renames into place.
  - A power loss during save should not leave a partial config file.

## What changed in v1.5.22

- Renamed the message editor label from OLED Message to Screen Message.
- Updated the Quick Message help text to explain the actual screen layout.
- The message entry box now vertically centers typed text like the real clock display.
- The preview keeps the face on the left and the message area on the right.

## What changed in v1.5.21

- Fixed the GCC `-Wformat-truncation` warning in multi-MP3 upload error handling.
- Upload error messages now clamp the displayed filename before formatting into the fixed error buffer.
- No functional change to MP3 upload behavior.

## What changed in v1.5.20

- Music upload now supports selecting and uploading multiple MP3 files at one time.
- The Quick Message page now uses the OLED preview itself as the text entry box.
- Removed the duplicate face/message preview below the face selector.

## What changed in v1.5.19

- Polished the GUI navigation.
  - Added a visible mobile menu bar under the header.
  - Log is now a direct menu item on phones instead of being hidden in a view selector.
  - Desktop still uses the left navigation menu.
- Reduced message preview flicker while typing.
  - The active uploaded font is now registered once and reused.
  - The preview no longer rewrites the `@font-face` rule on every keystroke.
  - Stale async message-fit responses are ignored so older wrap checks cannot redraw newer text.
  - Preview line nodes are updated in place instead of rebuilding the whole preview block each input event.
- Bumped browser asset cache versions to force the updated CSS and JS to load.

## What changed in v1.5.18

- `for_each_form_field()` now parses POST bodies in place with `strtok_r()`.
- Removed form-handler `strdup()` use from message and delete-font paths.
- Reworked per-alarm config save/load with generated X-macro loops.
- Removed `strdup()` from query parsing.
- Optimized `send_fonts_json()` with length-tracked `snprintf()`.

## What changed in v1.5.14

- Refactored the HTTP request dispatcher.
  - Replaced the long `else if` chain with a table-driven route list.
  - Added small route adapter wrappers so GET, POST, upload, and JSON endpoints share one dispatch path.
- Flattened the 5x7 font glyph lookup.
  - Replaced the large ASCII switch with a static 128-entry table plus a known-glyph bitmap.
  - Space remains valid instead of falling through to the unknown glyph.
- Consolidated config serialization.
  - Added X-macro lists for scalar and string config fields.
  - `save_config()` and `load_config()` now use the same field list for shared settings.
- Reduced JSON builder churn in high-use endpoints.
  - `send_status_json()` now escapes variable strings once and formats larger JSON chunks.
  - `send_faces_json()` now builds each face entry with one formatted append after escaping fields.
- Consolidated bulk delete handlers.
  - Face and music delete-all actions now share `handle_delete_assets()`.
  - Existing GUI routes and JSON responses are preserved.

## What changed in v1.5.13

- Hardened the built-in web server.
  - The HTTP listener now uses `poll()` instead of blocking forever in `accept()`.
  - Each client request runs in a detached pthread, so one slow or stalled socket cannot freeze the whole GUI.
  - Accepted sockets now receive strict read/write timeouts.
- Removed OLED flush heap churn.
  - `oled_flush_region_bytes()` now uses a static framebuffer-sized transfer buffer.
  - This removes repeated `malloc()` / `free()` cycles during clock redraws and blinking colon updates.
- Removed shelling out for Wi-Fi state.
  - The status icon now checks kernel interfaces directly.
  - No more `popen("iwgetid ...")`, avoiding fork/exec spikes during audio playback.
- Added a **Log** page in the GUI.
  - Shows recent system, alarm, message, upload, delete, and web action events.
  - The log is stored at `/opt/mk-piclock/config/event.log`.
  - Includes Refresh Log and Clear Log buttons.
- Improved **Quick Message** for phone use.
  - Larger message box and simpler Send to Clock button.
  - Shows a local sent confirmation after the OLED accepts the message.
  - Clears the text area after sending so the next message can be typed immediately.

- Added **Delete All Faces** in the Faces GUI.
  - Removes normal faces.
  - Removes bedtime faces.
  - Removes saved source PNGs and generated OLED RAW files.
  - Clears cached/previewed face state.
- Added **Delete All Music** in the Music GUI.
  - Removes all uploaded MP3 files.
  - Stops current playback.
  - Clears per-alarm selected music so alarms fall back to random uploaded MP3 after new music is added.
- Fixed the message preview line layout.
  - The browser preview no longer uses flex/gap layout for message lines.
  - Preview lines now use fixed row positions so line 3 does not visually drop lower than the first two.
  - OLED TrueType message drawing now uses stable font metrics and baseline positioning for all message lines.

## Included asset-generation prompt

This release includes a helper prompt for generating new OLED face sprite sheets:

```text
FACE_SPRITE_SHEET_AI_PROMPT.md
```

Use it with your preferred image model when creating new normal or bedtime face sheets. The prompt is designed around the mk-piclock OLED pipeline, including red grid safety, 64x64 crop safety, 4-level grayscale, and clean padding away from the crop boundaries.

## Hardware

Recommended target:

- Raspberry Pi Zero 2 W or similar Raspberry Pi
- SSD1322 256x64 grayscale OLED over 4-wire SPI
- MAX98357A I2S DAC/amp
- Small speaker

### OLED wiring

| OLED | Raspberry Pi |
| --- | --- |
| VCC | 3.3V |
| GND | GND |
| DIN / MOSI | GPIO10, pin 19 |
| CLK / SCLK | GPIO11, pin 23 |
| CS | SPI CE0 GPIO8 pin 24, or tied low if your module allows it |
| DC | GPIO25 |
| RST | GPIO27 |

Default OLED settings:

```text
/dev/spidev0.0
DC GPIO 25
RST GPIO 27
SPI 4 MHz
```

### MAX98357A wiring

| MAX98357A | Raspberry Pi |
| --- | --- |
| VIN | 5V or 3.3V, depending on module |
| GND | GND |
| BCLK | GPIO18, pin 12 |
| LRC / LRCLK | GPIO19, pin 35 |
| DIN | GPIO21, pin 40 |
| SD / EN | Not used with `no-sdmode` |

## Raspberry Pi OS setup

Edit `/boot/firmware/config.txt` on Bookworm, or `/boot/config.txt` on older Raspberry Pi OS:

```ini
dtparam=spi=on
dtparam=audio=off
dtoverlay=max98357a,no-sdmode
```

Reboot after changing boot config.

## Dependencies

Install build/runtime packages:

```bash
sudo apt update
sudo apt install --no-install-recommends -y \
  build-essential \
  pkg-config \
  libgpiod-dev \
  gpiod \
  libpng-dev \
  libfreetype-dev \
  libasound2-dev \
  libmpg123-dev \
  alsa-utils
```

## Build and install

For the detailed step-by-step deployment guide, see [`INSTALL.md`](INSTALL.md).

```bash
unzip mk-piclock-v1.5.23-final-optimization.zip
cd mk-piclock-v1.5.23-final-optimization

make clean
make
sudo make install
sudo systemctl restart mk-piclock
```

Open the GUI:

```text
http://<clock-ip>/
```

Example:

```text
http://192.168.24.95/
```

## Upgrade from an older version

```bash
unzip mk-piclock-v1.5.23-final-optimization.zip
cd mk-piclock-v1.5.23-final-optimization
make clean
make
sudo make install
sudo systemctl restart mk-piclock
```

Existing config and uploaded assets remain under `/opt/mk-piclock` unless you use the GUI delete functions.

## Runtime locations

```text
/opt/mk-piclock/mk-piclock
/opt/mk-piclock/web
/opt/mk-piclock/config/clock.conf
/opt/mk-piclock/assets/faces
/opt/mk-piclock/assets/bedtime-faces
/opt/mk-piclock/assets/music
/opt/mk-piclock/assets/fonts
```

## Optimal face images

Best source PNG:

```text
64x64 pixels
PNG
Square crop
High contrast
Grayscale-safe
Simple bold shapes
Transparent background is okay, but a black/opaque background is safest
```

On upload, the daemon stores:

```text
source PNG
OLED RAW face, packed 4-bit grayscale
```

Normal and bedtime faces are separate. Bedtime faces are only used during the configured bedtime window.

## Optimal sound format

Best alarm/music upload:

```text
MP3
44.1 kHz
Stereo or mono
128 to 192 kbps CBR preferred
Avoid extremely quiet normalized files
Avoid variable-rate files if you want predictable ramp timing
```

Music is decoded in the daemon using libmpg123 and sent directly to ALSA. Alarm ramping scales PCM samples directly. Alarm start/end volume overrides the global volume setting during alarm playback.

## Fonts

Supported font uploads:

```text
.ttf
.otf
```

Recommended clock fonts:

```text
Digital/seven-segment style
Bold numeric glyphs
Clear colon glyph
Reasonably uniform digit widths
```

Uploaded TrueType/OpenType fonts are used for the main clock and message text. The date/status text uses the fixed built-in 5x7 OLED font so it stays readable and does not clip.

## OLED layout notes

- Face is on the left side of the OLED.
- Wi-Fi pill is bottom-left.
- Alarm/music pill sits immediately to the right of the Wi-Fi pill.
- Clock center is calculated between the right edge of the face and the right edge of the OLED.
- Date uses the same calculated clock center.
- 12-hour mode centers visible `H:MM` or `HH:MM` without extra hidden whitespace.
- 24-hour mode uses full `HH:MM` layout.
- The colon blinks on/off. Numeric seconds are not shown.

## OLED font gamma correction

FreeType anti-aliased edges are gamma-corrected before being blended into the SSD1322 4-bit framebuffer. This prevents mid-gray curve pixels from looking too bright/fuzzy on the OLED and makes uploaded fonts look sharper.

## Bedtime dimming

Bedtime dimming uses both hardware OLED current settings and software framebuffer scaling. Use:

```text
100% = full brightness
20%  = dim
5-15% = very dim
0%   = near black
```

## GUI notes

- Faces can be uploaded as PNGs.
- The original source PNG is kept for GUI preview.
- Faces can be deleted individually or all at once.
- Music can be uploaded as MP3 files.
- Music can be deleted all at once.
- Message preview shows the selected face and wrapped text using the active OLED font when available.
- Message fit is checked by the daemon using the same wrap logic as the OLED renderer.

## Useful commands

```bash
sudo systemctl status mk-piclock
sudo systemctl restart mk-piclock
journalctl -u mk-piclock -f
```

Manual API checks:

```bash
curl http://127.0.0.1:8080/api/status
curl http://127.0.0.1:8080/api/faces
curl http://127.0.0.1:8080/api/music
```

## Troubleshooting

### OLED does not update

Check SPI and service logs:

```bash
ls -l /dev/spidev0.0
journalctl -u mk-piclock -f
```

### Audio does not play

Check ALSA devices:

```bash
aplay -l
speaker-test -D default -c2 -t sine
```

### Uploaded font looks fuzzy

Use a bold numeric font and avoid overly thin fonts. The OLED gamma LUT helps, but very thin antialiased fonts can still look soft on a 4-bit OLED.

### Message line 3 looks too low

v1.5.9 fixes the web preview row placement and stabilizes OLED TrueType baseline drawing. Rebuild and reinstall this version if line 3 appears lower than the first two.
