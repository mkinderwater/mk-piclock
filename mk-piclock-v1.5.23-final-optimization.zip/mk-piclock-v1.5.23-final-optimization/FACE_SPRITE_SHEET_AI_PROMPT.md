# AI Prompt: OLED Face Sprite Sheet

Create a wide sprite sheet of expressive cartoon girl reaction faces for a small OLED alarm clock.

## Canvas layout

- Use a clean grid layout.
- Each cell must contain one face or bedtime reaction.
- Add thin bright red grid lines separating every cell.
- The red grid lines must stay outside the artwork area.
- Leave at least 8 pixels of black padding between every face and every red grid line.
- Do not let hair, hands, pillows, blankets, ears, symbols, or shadows touch the red grid.
- Keep every face centered in its cell.
- No text labels inside cells.
- Black background.

## Crop safety

- Design each icon as if it will be cropped from inside the red cell with a 4 pixel inset on all sides.
- The useful artwork must remain fully visible after that inset crop.
- No red pixels, red glow, red anti-aliasing, or red reflection should appear inside the icon artwork area.
- Avoid placing bright highlights on the extreme left, right, top, or bottom edge of a cell.
- Each final crop must still look centered at 64x64 pixels.

## OLED style

- High contrast black and white OLED style.
- Use only 4 grayscale levels: black, dark gray, light gray, white.
- Bold outlines, readable at tiny size.
- More detailed than simple emoji, but not cluttered.
- Grayscale safe.
- Square-crop friendly.
- PNG sprite-sheet look.

## Content

- Faces must clearly communicate a person reaction.
- Use hands and small symbols when useful, such as question marks, sparkles, sweat drops, tears, Zzz marks, sheep, stars, pillows, blankets, teddy bears, lamps, and clocks.
- Make every face distinct.
- Keep all artwork inside the safe area, away from the red grid.
