# mk-piclock HTTP API 1.16

The GUI and add-ons use the HTTP API on port 8080.

```text
http://<clock-ip>:8080/api/v1
```

Every route is directly available to devices that can reach port 8080. Use the API only on a trusted home network and do not expose it to the internet.

## Discovery and status

```http
GET /api/v1
GET /api/v1/capabilities
GET /api/v1/openapi.json
GET /api/v1/health
GET /api/v1/status
```

## Images

```http
GET  /api/v1/assets/images
GET  /api/v1/assets/bedtime-images
GET  /api/v1/assets/images/source?file=<raw-name>
GET  /api/v1/assets/bedtime-images/source?file=<raw-name>
GET  /api/v1/assets/images/download
GET  /api/v1/assets/bedtime-images/download
POST /api/v1/assets/images/upload
POST /api/v1/assets/bedtime-images/upload
POST /api/v1/assets/images/delete
POST /api/v1/assets/bedtime-images/delete
POST /api/v1/assets/images/delete-all
POST /api/v1/assets/bedtime-images/delete-all
```

The Day and Bedtime download routes return ZIP archives containing only original PNG files.

## Music

```http
GET  /api/v1/assets/music
POST /api/v1/assets/music/upload
GET  /api/v1/assets/music/jobs
POST /api/v1/assets/music/jobs/clear
POST /api/v1/assets/music/delete
POST /api/v1/assets/music/delete-all
```

MP3 upload settings include bitrate, sample rate, and low-pass frequency. Only one file may be uploaded at a time, and uploads are refused while a job is queued or processing. `POST /api/v1/assets/music/jobs/clear` removes waiting jobs but does not interrupt the active transcoder.

## Display and messages

```http
POST /api/v1/display/action
GET  /api/v1/display/preview
POST /api/v1/display/brightness-preview
POST /api/v1/display/message
POST /api/v1/display/message/preview
```

`POST /api/v1/display/message/preview` accepts `image_file`, `image_bedtime`, and `message_text`, then returns the exact packed 4-bit 256x64 framebuffer without changing the physical OLED.

Messages accept:

```text
image_file=<image raw filename, optional; empty selects a random image>
image_bedtime=0 for Day Images or 1 for Bedtime Images
message_text=<optional text; an image-only message is allowed>
delay_seconds=0, 10, 30, or 60
scheduled_at=<Unix timestamp, optional, within 30 days>
```

## Configuration

```http
POST /api/v1/config/alarms
POST /api/v1/config/audio
POST /api/v1/config/personalization
POST /api/v1/config/display
```

## Activity

```http
GET  /api/v1/logs
POST /api/v1/logs/clear
```

## Compatibility

```text
HTTP API:    1.16
Private IPC: 11
```

See `api/openapi-v1.json` for the complete schema.
