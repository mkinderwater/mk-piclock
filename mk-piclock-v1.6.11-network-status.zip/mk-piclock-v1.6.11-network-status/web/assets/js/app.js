'use strict';

const host = document.querySelector('#module-host');
const noticeNode = document.querySelector('#action-notice');
const oledPill = document.querySelector('#oled-pill');
const clockNameHeading = document.querySelector('#clock-name-heading');
const menus = [document.querySelector('#mobile-menu'), document.querySelector('#sidebar-menu')];

let modules = [];
let current = null;
let status = null;
let statusTimer = null;
const statusListeners = new Set();

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

async function request(url, options = {}) {
    const response = await fetch(url, {cache: 'no-store', ...options});
    if (response.ok) return response;

    let message = await response.text();
    try {
        const parsed = JSON.parse(message);
        message = parsed.error || parsed.message || message;
    } catch (_) {}
    throw new Error(message || `HTTP ${response.status}`);
}

async function json(url, options) {
    return (await request(url, options)).json();
}

function notice(text = '', type = '', timeout = 0) {
    noticeNode.textContent = text;
    noticeNode.className = `action-notice ${type}`;
    noticeNode.classList.toggle('hidden', !text);
    if (timeout) {
        window.setTimeout(() => {
            if (noticeNode.textContent === text) noticeNode.classList.add('hidden');
        }, timeout);
    }
}

function busy(button, active, text = '') {
    if (!button) return;
    if (active) {
        button.dataset.label = button.textContent;
        button.disabled = true;
        if (text) button.textContent = text;
        return;
    }
    button.disabled = false;
    if (button.dataset.label) button.textContent = button.dataset.label;
    delete button.dataset.label;
}

async function update(url, options = {}) {
    const {
        method = 'GET', body = null, button = null,
        busyText = 'Processing request...', done = 'Request completed', errorText = 'Request failed', refreshStatus = true
    } = options;

    busy(button, true, busyText);
    notice(busyText, 'busy');
    try {
        const headers = body instanceof URLSearchParams
            ? {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}
            : {'Accept': 'application/json'};
        const response = await request(url, {method, body, headers});
        notice(done, 'ok', 1800);
        if (refreshStatus) await refreshStatusNow();
        return response;
    } catch (error) {
        notice(error.message || errorText, 'warn', 3500);
        throw error;
    } finally {
        busy(button, false);
    }
}

function clock(action, params = {}, button = null, feedback = {}) {
    const messages = {
        clock: {busyText: 'Restoring clock...', done: 'Clock display restored'},
        clear: {busyText: 'Clearing screen...', done: 'Screen cleared'},
        stop: {busyText: 'Stopping audio...', done: 'Audio stopped'},
        'play-music': {busyText: 'Starting music...', done: 'Music playback started'}
    };
    const defaults = messages[action] || {busyText: 'Sending clock command...', done: 'Clock command completed'};
    const body = new URLSearchParams({do: action, format: 'json', ...params});
    return update('/api/v1/display/action', {
        method: 'POST',
        body,
        button,
        busyText: feedback.busyText || defaults.busyText,
        done: feedback.done || defaults.done,
        errorText: feedback.errorText || 'Clock command failed'
    });
}

function formatUptime(value) {
    let seconds = Math.max(0, Number.parseInt(value || 0, 10));
    const days = Math.floor(seconds / 86400); seconds %= 86400;
    const hours = Math.floor(seconds / 3600); seconds %= 3600;
    const minutes = Math.floor(seconds / 60); seconds %= 60;
    if (days) return `${days}d ${hours}h ${minutes}m`;
    if (hours) return `${hours}h ${minutes}m ${seconds}s`;
    if (minutes) return `${minutes}m ${seconds}s`;
    return `${seconds}s`;
}

function timeValue(hour, minute) {
    return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

function subscribeStatus(callback, signal) {
    statusListeners.add(callback);
    if (status) callback(status);
    signal?.addEventListener('abort', () => statusListeners.delete(callback), {once: true});
}

async function refreshStatusNow() {
    try {
        status = await json('/api/v1/status');
        oledPill.textContent = status.oled_ok ? 'OLED OK' : 'OLED OFF';
        oledPill.className = status.oled_ok ? 'pill ok' : 'pill warn';
        const clockName = String(status.clock_name || '').trim() || 'mk-piclock';
        clockNameHeading.textContent = clockName;
        clockNameHeading.title = `Editing ${clockName}`;
        if (current) {
            const activeDefinition = definitionFor(current.id);
            document.title = `${activeDefinition?.name || 'Control'} | ${clockName}`;
        }
        statusListeners.forEach(callback => {
            try { callback(status); } catch (error) { console.error(error); }
        });
        return status;
    } catch (_) {
        oledPill.textContent = 'Offline';
        oledPill.className = 'pill warn';
        return null;
    }
}

function hashModule() {
    return location.hash.replace(/^#\/?/, '').split(/[/?]/)[0].trim();
}

function definitionFor(id) {
    return modules.find(item => item.id === id)
        || modules.find(item => item.default)
        || modules[0];
}

function navigate(id) {
    const definition = definitionFor(id);
    if (!definition) return;
    if (hashModule() === definition.id) loadModule(definition.id);
    else location.hash = definition.id;
}

function renderMenus() {
    menus.forEach(menu => {
        menu.replaceChildren(...modules.map(definition => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = menu.id === 'mobile-menu' ? 'nav-item mobile-nav-item' : 'nav-item';
            button.dataset.moduleId = definition.id;
            button.textContent = definition.name;
            button.addEventListener('click', () => navigate(definition.id));
            return button;
        }));
    });
}

function setActiveMenu(id) {
    document.querySelectorAll('[data-module-id]').forEach(button => {
        button.classList.toggle('active', button.dataset.moduleId === id);
    });
}

function moduleContext(controller) {
    const $ = selector => host.querySelector(selector);
    const $$ = selector => [...host.querySelectorAll(selector)];
    const set = (selector, property, value) => {
        const node = $(selector);
        if (node) node[property] = value == null ? '' : String(value);
    };
    const on = (type, selector, handler, target = host) => {
        target.addEventListener(type, event => {
            const match = event.target.closest(selector);
            if (match && target.contains(match)) handler(event, match);
        }, {signal: controller.signal});
    };

    return Object.freeze({
        root: host,
        signal: controller.signal,
        $,
        $$,
        on,
        html: escapeHtml,
        setText: (selector, value) => set(selector, 'textContent', value),
        setValue: (selector, value) => set(selector, 'value', value),
        json,
        update,
        clock,
        notice,
        busy,
        formatUptime,
        timeValue,
        status: Object.freeze({
            get: () => status,
            refresh: refreshStatusNow,
            subscribe: callback => subscribeStatus(callback, controller.signal)
        })
    });
}

async function loadModule(id) {
    const definition = definitionFor(id);
    if (!definition || current?.id === definition.id) return;

    current?.controller.abort();
    current?.css.remove();

    const controller = new AbortController();
    const base = `/modules/${encodeURIComponent(definition.id)}`;
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = `${base}/module.css?v=169`;
    document.head.appendChild(css);
    current = {id: definition.id, controller, css, refresh: null};

    setActiveMenu(definition.id);
    host.innerHTML = `<div class="card module-loading">Loading ${escapeHtml(definition.name)}...</div>`;

    try {
        const [html, moduleObject] = await Promise.all([
            request(`${base}/module.html`).then(response => response.text()),
            import(`${base}/module.js?v=169`)
        ]);
        if (controller.signal.aborted) return;

        host.innerHTML = html;
        document.title = `${definition.name} | ${String(status?.clock_name || '').trim() || 'mk-piclock'}`;
        const mounted = await moduleObject.mount?.(moduleContext(controller));
        if (!controller.signal.aborted) current.refresh = mounted?.refresh || null;
    } catch (error) {
        if (controller.signal.aborted) return;
        css.remove();
        current = null;
        host.innerHTML = `<div class="card module-error"><h2>Module failed</h2><p>${escapeHtml(error.message)}</p></div>`;
        notice(`${definition.name} could not load`, 'warn', 3500);
    }
}

host.addEventListener('submit', async event => {
    const form = event.target.closest('form');
    if (!form || form.dataset.moduleHandlesSubmit === 'true') return;
    event.preventDefault();

    const multipart = form.enctype.includes('multipart/form-data');
    const body = multipart ? new FormData(form) : new URLSearchParams(new FormData(form));
    if (!multipart) body.set('format', 'json');
    const button = event.submitter || form.querySelector('[type="submit"]');

    try {
        await update(form.action, {
            method: (form.method || 'POST').toUpperCase(),
            body,
            button,
            busyText: form.dataset.busyText || (multipart ? 'Uploading files...' : 'Saving changes...'),
            done: form.dataset.successText || (multipart ? 'Files uploaded' : 'Changes saved'),
            errorText: form.dataset.errorText || (multipart ? 'Upload failed' : 'Changes could not be saved')
        });
        await current?.refresh?.();
    } catch (_) {}
});


async function start() {
    try {
        const manifest = await json('/modules/modules.json');
        modules = (manifest.modules || [])
            .filter(item => item?.enabled === true && /^[a-z0-9_-]+$/i.test(item.id || ''))
            .sort((a, b) => (a.order || 0) - (b.order || 0));
        renderMenus();
        await refreshStatusNow();
        statusTimer = window.setInterval(refreshStatusNow, 5000);
        navigate(hashModule());
    } catch (error) {
        host.innerHTML = `<div class="card module-error"><h2>Interface failed</h2><p>${escapeHtml(error.message)}</p></div>`;
        oledPill.textContent = 'GUI ERROR';
        oledPill.className = 'pill warn';
    }
}

window.addEventListener('hashchange', () => loadModule(hashModule()));
window.addEventListener('beforeunload', () => {
    current?.controller.abort();
    if (statusTimer) window.clearInterval(statusTimer);
});

start();
